import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class AddStock extends JFrame {

	private JPanel contentPane;
	private JTextField addstockcnt;
	private JButton canceladdstockbtn;
	private JButton addstockokbtn;
	
	private int stockresult;
	
    //Stock stock = new Stock();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddStock frame = new AddStock();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public int getStockResult() {return stockresult;}

	/**
	 * Create the frame.
	 */
	public AddStock() {};
	public AddStock(Stock stock, DefaultTableModel m, JTable table) {
		

		setTitle("\uC7AC\uACE0 \uCD94\uAC00");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\uCD94\uAC00\uD560 \uC218\uB7C9");
		label.setFont(new Font("���������� Bold", Font.PLAIN, 17));
		label.setBounds(46, 50, 127, 36);
		contentPane.add(label);
		
		addstockcnt = new JTextField();
		addstockcnt.setFont(new Font("����������", Font.PLAIN, 15));
		addstockcnt.setBounds(69, 112, 293, 66);
		contentPane.add(addstockcnt);
		addstockcnt.setColumns(10);
		
		canceladdstockbtn = new JButton("\uCDE8\uC18C");
		canceladdstockbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		canceladdstockbtn.setFont(new Font("����������", Font.PLAIN, 15));
		canceladdstockbtn.setBackground(new Color(242, 242, 242));
		canceladdstockbtn.setBounds(105, 217, 90, 23);
		contentPane.add(canceladdstockbtn);
		
		addstockokbtn = new JButton("\uD655\uC778");
		addstockokbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // ����Ʈ���� ���õ� �Ҹ�ǰ ��� �߰�
				stockresult = Integer.parseInt(addstockcnt.getText());
				System.out.print(stockresult);
				for(int i=0;i<4;i++)
					if(stock.drinkstock[i].equals(m.getValueAt(table.getSelectedRow(), 0))) {
						stock.drinkstockcnt[i] += stockresult;
						m.setValueAt(stock.drinkstockcnt[i], table.getSelectedRow(), 1);
						System.out.print("drink - " + stock.drinkstockcnt[i]);
						table.updateUI();
					}

				for(int i=0;i<2;i++)
					if(stock.dessertstock[i].equals(m.getValueAt(table.getSelectedRow(), 0))) {
						stock.dessertstockcnt[i] += stockresult;
						m.setValueAt(stock.dessertstockcnt[i], table.getSelectedRow(), 1);
						System.out.print("dessert - " + stock.dessertstockcnt[i]);
						//m.fireTableDataChanged();
						table.updateUI();
					}
				if(stock.tissuestock.equals(m.getValueAt(table.getSelectedRow(), 0))) {
					stock.tissuecnt += stockresult;
					m.setValueAt(stock.tissuecnt, table.getSelectedRow(), 1);
					System.out.print("tissue - " + stock.tissuecnt);
					table.updateUI();
				}
				dispose();
			}
		});
		addstockokbtn.setFont(new Font("����������", Font.PLAIN, 15));
		addstockokbtn.setBackground(new Color(242, 242, 242));
		addstockokbtn.setBounds(232, 217, 90, 23);
		contentPane.add(addstockokbtn);
		
	}

}
