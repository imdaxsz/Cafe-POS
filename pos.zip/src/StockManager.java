import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class StockManager extends JFrame {
	/**
	 * Launch the application.
	 */
	
	String []a = {"��ǰ��","����"};
    
    DefaultTableModel model = new DefaultTableModel(a, 0) {
    	public boolean isCellEditable(int rowIndex, int mColIndex) {
    		return false;
    	}
    };
    JTable table = new JTable(model);
	JScrollPane scrollPane = new JScrollPane(table);
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StockManager frame = new StockManager();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public StockManager() {};
	public StockManager(Stock stock) {
		setTitle("\uC7AC\uACE0\uAD00\uB9AC");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 767, 640);
		JPanel stockpane = new JPanel();
		stockpane.setBackground(SystemColor.inactiveCaptionBorder);
		stockpane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(stockpane);
		stockpane.setLayout(null);
		
		JTextField searchname = new JTextField();
		searchname.setFont(new Font("����������", Font.PLAIN, 15));
		searchname.setText("");
		searchname.setBounds(86, 74, 455, 45);
		stockpane.add(searchname);
		searchname.setColumns(10);
		
		JButton btnstmgecancel = new JButton("\uCDE8\uC18C");
		btnstmgecancel.setBackground(new Color(242, 242, 242));
		btnstmgecancel.setFont(new Font("����������", Font.PLAIN, 15));
		btnstmgecancel.setBounds(253, 534, 100, 30);
		stockpane.add(btnstmgecancel);
		btnstmgecancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnstmgeok = new JButton("\uD655\uC778");
		btnstmgeok.setBackground(new Color(242, 242, 242));
		btnstmgeok.setFont(new Font("����������", Font.PLAIN, 15));
		btnstmgeok.setBounds(380, 534, 100, 30);
		stockpane.add(btnstmgeok);
		
		JLabel lbsearchstock = new JLabel("\uC7AC\uACE0 \uAC80\uC0C9");
		lbsearchstock.setForeground(new Color(0, 0, 139));
		lbsearchstock.setFont(new Font("����������", Font.BOLD, 18));
		lbsearchstock.setBounds(86, 22, 139, 48);
		stockpane.add(lbsearchstock);
		
		JLabel lbsearchresult = new JLabel("\uAC80\uC0C9 \uACB0\uACFC");
		lbsearchresult.setForeground(new Color(0, 0, 128));
		lbsearchresult.setFont(new Font("����������", Font.BOLD, 18));
		lbsearchresult.setBounds(86, 138, 139, 48);
		stockpane.add(lbsearchresult);
		

		scrollPane.setBounds(86, 191, 573, 241);
		stockpane.add(scrollPane);
        table.getColumnModel().getColumn(0).setPreferredWidth(130); 
        table.getColumnModel().getColumn(0).setResizable(false);
        table.getColumnModel().getColumn(1).setPreferredWidth(15); 
        table.getColumnModel().getColumn(1).setResizable(false);
        table.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(table);
		table.setBackground(Color.WHITE);
		
        table.updateUI();
             
		JButton btnsearch = new JButton("\uAC80\uC0C9");
		btnsearch.setForeground(Color.WHITE);
		btnsearch.setFont(new Font("����������", Font.BOLD, 15));
		btnsearch.setBounds(556, 74, 101, 45);
		btnsearch.setBackground(new Color(140, 190, 255));
		stockpane.add(btnsearch);
		
		btnsearch.addActionListener(new ActionListener() { // �Ҹ�ǰ ��� �˻�
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
				int resultcnt = 0;

				for(String result:stock.stocklist) {
					int cnt = 0;
					int index = 0;
					if(result.contains(searchname.getText())) {
						resultcnt=1;
						for(int i=0;i<4;i++)
							if(stock.drinkstock[i].equals(result))
								cnt=stock.drinkstockcnt[i];
						for(int i=0;i<2;i++)
							if(stock.dessertstock[i].equals(result))
								cnt=stock.dessertstockcnt[i];
						if(stock.tissuestock.equals(result))
							cnt=stock.tissuecnt;
						model.insertRow(index++,new Object[]{result,cnt});
					}
					
				}
				model.fireTableDataChanged();
				if(resultcnt==0) {
					JOptionPane mgsnoresult=new JOptionPane();
					mgsnoresult.showMessageDialog(null, "�˻� ����� �����ϴ�.", "��� �˻�", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		JButton btnaddstock = new JButton("\uC7AC\uACE0 \uCD94\uAC00");
		btnaddstock.setForeground(Color.WHITE);
		btnaddstock.setFont(new Font("����������", Font.BOLD, 15));
		btnaddstock.setBounds(545, 449, 110, 42);
		btnaddstock.setBackground(new Color(140, 190, 255));
		stockpane.add(btnaddstock);
		
		
		
		btnaddstock.addActionListener(new ActionListener() { // ��� �߰� ��ư
			public void actionPerformed(ActionEvent e) {
				AddStock addstock = new AddStock(stock, model, table);
				addstock.setVisible(true);
			}
		});
		
		btnstmgeok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
	
}
