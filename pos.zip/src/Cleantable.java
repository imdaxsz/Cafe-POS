import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Cleantable extends JFrame {

	private JPanel cleantbpn;
	private JRadioButton rbclntb1, rbclntb2, rbclntb3, rbclntb4, rbclntb5, rbclntb6, rbclntb7, rbclntb8, rbclntb9;
	private JButton clntbokbtn, clncancelbtn;
	public boolean cleanok = false;
	
	//public Table[] ResultTableList = new Table[9];
	static int selected;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cleantable frame = new Cleantable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public Cleantable() {
		cleanok = false;
		selected = 0;
		setTitle("���̺� ġ���");
		//setTitle("\uD14C\uC774\uBE14 \uCE58\uC6B0\uAE30");
		//ResultTableList = tablelist;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		cleantbpn = new JPanel();
		cleantbpn.setBackground(SystemColor.inactiveCaptionBorder);
		cleantbpn.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(cleantbpn);
		cleantbpn.setLayout(null);
		
		rbclntb1 = new JRadioButton("\uD14C\uC774\uBE14 1");
		rbclntb1.setBackground(Color.WHITE);
		rbclntb1.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb1.setBounds(95, 69, 120, 30);
		cleantbpn.add(rbclntb1);
		
		rbclntb2 = new JRadioButton("\uD14C\uC774\uBE14 2");
		rbclntb2.setBackground(Color.WHITE);
		rbclntb2.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb2.setBounds(242, 69, 120, 30);
		cleantbpn.add(rbclntb2);
		
		rbclntb3 = new JRadioButton("\uD14C\uC774\uBE14 3");
		rbclntb3.setBackground(Color.WHITE);
		rbclntb3.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb3.setBounds(395, 69, 104, 30);
		cleantbpn.add(rbclntb3);
		
		rbclntb4 = new JRadioButton("\uD14C\uC774\uBE14 4");
		rbclntb4.setBackground(Color.WHITE);
		rbclntb4.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb4.setBounds(95, 149, 120, 30);
		cleantbpn.add(rbclntb4);
		
		rbclntb5 = new JRadioButton("\uD14C\uC774\uBE14 5");
		rbclntb5.setBackground(Color.WHITE);
		rbclntb5.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb5.setBounds(242, 149, 120, 30);
		cleantbpn.add(rbclntb5);
		
		rbclntb6 = new JRadioButton("\uD14C\uC774\uBE14 6");
		rbclntb6.setBackground(Color.WHITE);
		rbclntb6.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb6.setBounds(395, 149, 104, 30);
		cleantbpn.add(rbclntb6);
		
		rbclntb7 = new JRadioButton("\uD14C\uC774\uBE14 7");
		rbclntb7.setBackground(Color.WHITE);
		rbclntb7.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb7.setBounds(95, 229, 120, 30);
		rbclntb7.setVisible(false);
		cleantbpn.add(rbclntb7);
		
		rbclntb8 = new JRadioButton("\uD14C\uC774\uBE14 8");
		rbclntb8.setBackground(Color.WHITE);
		rbclntb8.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb8.setBounds(242, 229, 120, 30);
		rbclntb8.setVisible(false);
		cleantbpn.add(rbclntb8);
		
		rbclntb9 = new JRadioButton("\uD14C\uC774\uBE14 9");
		rbclntb9.setBackground(Color.WHITE);
		rbclntb9.setFont(new Font("����������", Font.PLAIN, 15));
		rbclntb9.setBounds(395, 229, 104, 30);
		rbclntb9.setVisible(false);
		
		cleantbpn.add(rbclntb9);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rbclntb1); group.add(rbclntb2); group.add(rbclntb3); group.add(rbclntb4); group.add(rbclntb5);
		group.add(rbclntb6); group.add(rbclntb7); group.add(rbclntb8); group.add(rbclntb9);
		
		JRadioButton[] rbtable = {rbclntb1, rbclntb2, rbclntb3, rbclntb4, rbclntb5, rbclntb6, rbclntb7, rbclntb8, rbclntb9};
		
		for(int i=0;i<9;i++) {
			rbtable[i].setSelected(false);
		}
		
		for(int i=0;i<9;i++) {
			int k = i;
			rbtable[i].addItemListener(new ItemListener() {
			    public void itemStateChanged(ItemEvent e) {
			    	if(rbtable[k].isSelected())
			    		selected = k;
			    }
			});
		}
		
		clntbokbtn = new JButton("\uD655\uC778");
		clntbokbtn.setForeground(Color.BLACK);
		clntbokbtn.setFont(new Font("����������", Font.PLAIN, 15));
		clntbokbtn.setBounds(300, 330, 90, 23);
		clntbokbtn.setBackground(new Color(242, 242, 242));
		cleantbpn.add(clntbokbtn);
		
		clncancelbtn = new JButton("\uCDE8\uC18C");
		clncancelbtn.setForeground(Color.BLACK);
		clncancelbtn.setFont(new Font("����������", Font.PLAIN, 15));
		clncancelbtn.setBounds(173, 330, 90, 23);
		clncancelbtn.setBackground(new Color(242, 242, 242));
		cleantbpn.add(clncancelbtn);
		
		JPanel cleantbpanel = new JPanel();
		cleantbpanel.setBackground(Color.WHITE);
		cleantbpanel.setBounds(58, 47, 457, 234);
		cleantbpn.add(cleantbpanel);
		
		clncancelbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
	
	public void Cleantb(Table[] tablelist) {
		
		clntbokbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tablelist[selected].resettable(); // ���̺� ����(����)
				cleanok = true; // ���� �Ϸ�
				dispose();
			}
		});
		
	};
	
	public void AddTable(int count) { // ���̺��� �߰��Ǿ��� �� ���� ��ư Ȱ��ȭ
		JRadioButton[] rbtable = {rbclntb1, rbclntb2, rbclntb3, rbclntb4, rbclntb5, rbclntb6, rbclntb7, rbclntb8, rbclntb9};
		for(int i=0;i<count;i++) {
			if(rbtable[i].isVisible()==false) {
				rbtable[i].setVisible(true);

			}
		}
	}
	
}
