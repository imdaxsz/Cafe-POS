import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;


public class CafePOS extends JFrame implements Runnable {
	
	String file = "SalesHistory.txt";
	
	public static Stock stockcnt = new Stock();

	private Thread thread;
	private JPanel posmain;
	private JLabel TimeLabel1;
	private JLabel TimeLabel2;
	private JTextArea stocktext;
	private JTextArea txatborderlist;

	public int tablecnt = 6;
	public Tborderlist tborderlist = new Tborderlist();
	public Tableorder tborder = new Tableorder();
	public Extraorder exorder = new Extraorder();
	public Cleantable cleantb = new Cleantable();
	
	public static Table[] tableorderlist = new Table[9];
	public static DefaultTableModel model;
	public static JTable table;
	public JButton dessertbtn;
	public JButton drinkbtn;
	public JPanel stpn;
	
	public static int menuclicked = 1;
	public int[] eatendcnt = new int[9]; 
	
	public JButton[] dessmenubtnmge;
	public JButton[] drinkmenubtnmge;
	
	public Drink drinkorder = new Drink();
	public Accessory accorder = new Accessory();
	public Dessert dessorder = new Dessert();
	
	public int[] drinkclickcnt = new int[9];
	public int[] dessclickcnt = new int[9];
	public int[] accclickcnt = new int[5];
	
	public String tbordertext = "";
	public JButton btntborder;
	public JButton menubtn;
	public Option selectedopt = new Option();
	public static Vector<Option> drinkopt = new Vector<Option>();
	public static int optcnt = 0;
	public static int drinkoptidx = 0;
	
	public static Vector<String> ordermenu = new Vector<String>();
	public static Vector<Integer> ordermenucnt = new Vector<Integer>();
	public static Vector<String> ordermenutype = new Vector<String>();
	
	static int ordertotalcnt = 0;
	
	public JButton tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8, tb9;
	public JButton[] tablebtnlist = {tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8, tb9};
	
	public JCheckBox cbhot, cbice, cbshot, cbsyrup, cbwhipping;
	public JCheckBox[] cbdrinkopt = {cbshot, cbsyrup, cbwhipping};
	
	public static Vector<String> orderdetail1 = new Vector<String>();
	public static Vector<String> orderdetail2 = new Vector<String>();
	public static Vector<String> orderdetail3 = new Vector<String>();
	public static Vector<String> orderdetail4 = new Vector<String>();
	public static Vector<String> orderdetail5 = new Vector<String>();
	public static Vector<String> orderdetail6 = new Vector<String>();
	public static Vector<String> orderdetail7 = new Vector<String>();
	public static Vector<String> orderdetail8 = new Vector<String>();
	public static Vector<String> orderdetail9 = new Vector<String>();
	
	public static Vector<Vector<String>> orderdetail = new Vector<Vector<String>>(9);
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//CafePOS frame = new CafePOS(1, "����");
					CafePOS frame = new CafePOS();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CafePOS() {};
	//int membernum, String membername
	public CafePOS(int membernum, String membername) {
		orderdetail.add(orderdetail1); orderdetail.add(orderdetail2); orderdetail.add(orderdetail3);
		orderdetail.add(orderdetail4); orderdetail.add(orderdetail5); orderdetail.add(orderdetail6);
		orderdetail.add(orderdetail7); orderdetail.add(orderdetail8); orderdetail.add(orderdetail9);

		for(int i=0;i<9;i++)
			eatendcnt[i] = 0;
	
		
		stockcnt.StockList();
		setTitle("KUMOHYA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1097, 679);
		posmain = new JPanel();
		posmain.setBackground(new Color(255, 255, 255));
		posmain.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(posmain);
		posmain.setLayout(null);
		
		JLabel lbposition = new JLabel();
		lbposition.setText("\uBBF8\uD76C (\uB9C8\uC2A4\uD130)");
		lbposition.setHorizontalAlignment(SwingConstants.RIGHT);
		lbposition.setFont(new Font("���������� Bold", Font.BOLD, 20));
		lbposition.setBounds(866, 27, 195, 35);
		posmain.add(lbposition);
		
		// �ֹ�, ���̺�, ���, �޴� ��ư
		JButton orderbtn = new JButton("\uC8FC\uBB38\uD558\uAE30"); // �ֹ��ϱ� ��ư
		orderbtn.setForeground(Color.WHITE);
		orderbtn.setBackground(new Color(45, 110, 170));
		orderbtn.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		orderbtn.setBounds(870, 152, 192, 65);
		posmain.add(orderbtn);
		
		JButton tablebtn = new JButton("\uD14C\uC774\uBE14"); // ���̺� ��ư
		tablebtn.setForeground(Color.WHITE);
		tablebtn.setBackground(new Color(90,155,215));
		tablebtn.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		tablebtn.setBounds(870, 240, 192, 65);
		posmain.add(tablebtn);
		
		JButton stockbtn = new JButton("\uC7AC\uACE0\uAD00\uB9AC"); // ��� ��ư
		stockbtn.setForeground(Color.WHITE);
		stockbtn.setBackground(new Color(90,155,215));
		stockbtn.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		stockbtn.setBounds(870, 329, 192, 65);
		posmain.add(stockbtn);
		
		menubtn = new JButton("\uBA54\uB274\uAD00\uB9AC"); // �޴� ���� ��ư
		menubtn.setForeground(Color.WHITE);
		menubtn.setBackground(new Color(90,155,215));
		menubtn.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		menubtn.setBounds(870, 417, 192, 65);
		posmain.add(menubtn);
		
		JButton salesbtn = new JButton("\uD310\uB9E4\uB0B4\uC5ED"); // �Ǹ� ���� ��ư
		salesbtn.setForeground(Color.WHITE);
		salesbtn.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		salesbtn.setBackground(new Color(90, 155, 215));
		salesbtn.setBounds(870, 504, 192, 65);
		posmain.add(salesbtn);
/*
		// ������ ��޿� ���� �޴����� ��ư Ȱ��ȭ �� ������ ���� ȭ�� ���
		if (membernum == 1){
			menubtn.setEnabled(true);
			lbposition.setText(membername + " (������)");
		
		}

		else if (membernum == 2){
			menubtn.setEnabled(false);
			lbposition.setText(membername + " (�Ŵ���)");
			menubtn.setBackground(new Color(242, 242, 242));
		}
		else {
			menubtn.setEnabled(false);
			lbposition.setText(membername + " (����)");
			menubtn.setBackground(new Color(242, 242, 242));
		}
	*/	
		JPanel ordermanager = new JPanel();
		ordermanager.setBackground(SystemColor.inactiveCaptionBorder);
		ordermanager.setBounds(14, 15, 840, 610);
		posmain.add(ordermanager);
		ordermanager.setLayout(null);
		
		JTextField lborderlist = new JTextField("\uC8FC\uBB38 \uB0B4\uC5ED");  // ��
		lborderlist.setEditable(false);
		lborderlist.setBackground(new Color(255, 255, 255));
		lborderlist.setBounds(588, 81, 240, 28);
		ordermanager.add(lborderlist);
		lborderlist.setFont(new Font("���������� Bold", Font.PLAIN, 15));
		
		String []a = {"��ǰ��","����"}; // �ֹ� ���� ����Ʈ

        model = new DefaultTableModel(a, 0) {
        	public boolean isCellEditable(int rowIndex, int mColIndex) {
        		return false;
        	}
        };
        table = new JTable(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(120); 
        table.getColumnModel().getColumn(0).setResizable(false);
        table.getColumnModel().getColumn(1).setPreferredWidth(15); 
        table.getColumnModel().getColumn(1).setResizable(false);
        table.getTableHeader().setReorderingAllowed(false);
        JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(588, 109, 240, 230);
		ordermanager.add(scrollPane);
		
		table.setBackground(Color.WHITE);
		scrollPane.setViewportView(table);
		
        table.updateUI();
		
		JPanel menupn = new JPanel();
		menupn.setBounds(18, 88, 558, 411);
		ordermanager.add(menupn);
		menupn.setBackground(Color.WHITE);
		menupn.setForeground(Color.WHITE);
		menupn.setLayout(null);
		
		JPanel drinkmenu = new JPanel();
		drinkmenu.setBounds(0, 0, 558, 411);
		menupn.add(drinkmenu);
		drinkmenu.setLayout(null);
		drinkmenu.setForeground(Color.WHITE);
		drinkmenu.setBackground(Color.WHITE);
		
		cbhot = new JCheckBox("HOT");
		cbhot.setEnabled(false);
		cbhot.setHorizontalAlignment(SwingConstants.LEFT);
		cbhot.setFont(new Font("����������", Font.PLAIN, 15));
		cbhot.setBackground(Color.WHITE);
		cbhot.setBounds(145, 315, 109, 23);
		drinkmenu.add(cbhot);
		cbhot.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				hoticeoptevent(table);
			}
		});
		
		cbice = new JCheckBox("ICE");
		cbice.setFont(new Font("����������", Font.PLAIN, 15));
		cbice.setEnabled(false);
		cbice.setBackground(Color.WHITE);
		cbice.setBounds(330, 315, 109, 23);
		drinkmenu.add(cbice);
		cbice.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				hoticeoptevent(table);
			}
		});
		
		JCheckBox cbnoopt = new JCheckBox("\uCD94\uAC00 \uC5C6\uC74C");
		cbnoopt.setEnabled(false);
		cbnoopt.setFont(new Font("����������", Font.PLAIN, 15));
		cbnoopt.setBackground(Color.WHITE);
		cbnoopt.setBounds(63, 356, 99, 23);
		drinkmenu.add(cbnoopt);
		
		cbshot = new JCheckBox("\uC0F7 \uCD94\uAC00");
		cbshot.setEnabled(false);
		cbshot.setFont(new Font("����������", Font.PLAIN, 15));
		cbshot.setBackground(Color.WHITE);
		cbshot.setBounds(181, 356, 91, 23);
		drinkmenu.add(cbshot);
		
		cbsyrup = new JCheckBox("\uC2DC\uB7FD \uCD94\uAC00");
		cbsyrup.setEnabled(false);
		cbsyrup.setFont(new Font("����������", Font.PLAIN, 15));
		cbsyrup.setBackground(Color.WHITE);
		cbsyrup.setBounds(283, 356, 109, 23);
		drinkmenu.add(cbsyrup);
		
		cbwhipping = new JCheckBox("\uD718\uD551 \uCD94\uAC00");
		cbwhipping.setEnabled(false);
		cbwhipping.setFont(new Font("����������", Font.PLAIN, 15));
		cbwhipping.setBackground(Color.WHITE);
		cbwhipping.setBounds(401, 356, 109, 23);
		drinkmenu.add(cbwhipping);
		
		JCheckBox[] cbdrink_opt = {cbshot, cbsyrup, cbwhipping};
		

		for(int i=0;i<3;i++) {
			int o = i;

			cbdrink_opt[i].addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					optcnt++;
					if(optcnt == 1)
						drinkoptidx = model.getRowCount()-1;
					
					switch(o) {
					case 0:
						if(e.getStateChange()==1) {
							model.insertRow(table.getRowCount(), new Object[]{"+"+drinkorder.optname[o+1],"-"});
							selectedopt.shot = "��";
							if(optcnt == 1)
								drinkopt.add(selectedopt);
							else {
								drinkopt.set(drinkoptidx, selectedopt);
							}
						}
						break;
					case 1:
						if(e.getStateChange()==1) {				
							model.insertRow(table.getRowCount(), new Object[]{"+"+drinkorder.optname[o+1],"-"});
							selectedopt.syrup="�÷�";
							if(optcnt == 1)
								drinkopt.add(selectedopt);
							else
								drinkopt.set(drinkoptidx, selectedopt);
							
						}
						break;
					case 2:
						if(e.getStateChange()==1) {
							model.insertRow(table.getRowCount(), new Object[]{"+"+drinkorder.optname[o+1],"-"});
							selectedopt.whipping="����";
							if(optcnt == 1)
								drinkopt.add(selectedopt);
							else
								drinkopt.set(drinkoptidx, selectedopt);
						}
						break;
					}
				}
			});
		}
		
		cbdrinkopt = cbdrink_opt;

		JButton btame = new JButton("\uC544\uBA54\uB9AC\uCE74\uB178");
		btame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//selectedopt.InitOption();
				drinkoptidx = 0;
				optcnt = 0;
				cbhot.setVisible(true);
				cbice.setVisible(true);
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);

				cbshot.setEnabled(true);
				cbsyrup.setEnabled(true);
				cbwhipping.setEnabled(false);
				cbhot.setEnabled(true);
				cbice.setEnabled(true);
				drinkorderevent(0, table);
			}
		});
		btame.setBackground(new Color(242, 242, 242));
		btame.setFont(new Font("����������", Font.PLAIN, 15));
		btame.setBounds(50, 42, 129, 60);
		drinkmenu.add(btame);
		
		JButton btlatte = new JButton("\uCE74\uD398\uB77C\uB5BC");
		btlatte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//selectedopt.InitOption();
				drinkoptidx = 0;
				optcnt = 0;
				cbhot.setVisible(true);
				cbice.setVisible(true);
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
				
				cbshot.setEnabled(true);
				cbsyrup.setEnabled(true);
				cbwhipping.setEnabled(false);
				cbhot.setEnabled(true);
				cbice.setEnabled(true);
				drinkorderevent(1, table);
			}
		});
		btlatte.setBackground(new Color(242, 242, 242));
		btlatte.setFont(new Font("����������", Font.PLAIN, 15));
		btlatte.setBounds(212, 42, 129, 60);
		drinkmenu.add(btlatte);
		
		JButton btmocha = new JButton("\uCE74\uD398\uBAA8\uCE74");
		btmocha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drinkoptidx = 0;
				optcnt = 0;
				cbhot.setVisible(true);
				cbice.setVisible(true);
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
				
				cbshot.setEnabled(true);
				cbsyrup.setEnabled(true);
				cbwhipping.setEnabled(true);
				cbhot.setEnabled(true);
				cbice.setEnabled(true);
				drinkorderevent(2, table);

			}
		});
		btmocha.setBackground(new Color(242, 242, 242));
		btmocha.setFont(new Font("����������", Font.PLAIN, 15));
		btmocha.setBounds(374, 42, 129, 60);
		drinkmenu.add(btmocha);
		
		JButton btmktea = new JButton("\uBC00\uD06C\uD2F0");
		btmktea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drinkoptidx = 0;
				optcnt = 0;
				cbhot.setVisible(true);
				cbice.setVisible(true);
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
				
				cbshot.setEnabled(false);
				cbsyrup.setEnabled(false);
				cbwhipping.setEnabled(false);
				cbhot.setEnabled(true);
				cbice.setEnabled(true);
				drinkorderevent(3, table);

			}
		});
		btmktea.setBackground(new Color(242, 242, 242));
		btmktea.setFont(new Font("����������", Font.PLAIN, 15));
		btmktea.setBounds(50, 137, 129, 60);
		drinkmenu.add(btmktea);
		
		JButton btgrntea = new JButton("\uADF8\uB9B0\uD2F0\uD504\uB77C\uD478\uCE58\uB178");
		btgrntea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//selectedopt.InitOption();
				drinkoptidx = 0;
				optcnt = 0;
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);

				cbshot.setEnabled(false);
				cbsyrup.setEnabled(false);
				cbwhipping.setEnabled(true);
				cbhot.setVisible(false);
				cbice.setVisible(false);
				drinkorderevent(4, table);

			}
		});
		btgrntea.setBackground(new Color(242, 242, 242));
		btgrntea.setFont(new Font("����������", Font.PLAIN, 12));
		btgrntea.setBounds(212, 137, 129, 60);
		drinkmenu.add(btgrntea);
		
		JButton btstbsmd = new JButton("\uB538\uAE30\uC2A4\uBB34\uB514");
		btstbsmd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
				
				cbshot.setEnabled(false);
				cbsyrup.setEnabled(false);
				cbwhipping.setEnabled(false);
				cbhot.setVisible(false);
				cbice.setVisible(false);
				drinkorderevent(5, table);

			}
		});
		btstbsmd.setBackground(new Color(242, 242, 242));
		btstbsmd.setFont(new Font("����������", Font.PLAIN, 15));
		btstbsmd.setBounds(374, 137, 129, 60);
		drinkmenu.add(btstbsmd);
		
		JButton btlemade = new JButton("\uB808\uBAAC\uC5D0\uC774\uB4DC");
		btlemade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
				
				cbshot.setEnabled(false);
				cbsyrup.setEnabled(false);
				cbwhipping.setEnabled(false);
				cbhot.setVisible(false);
				cbice.setVisible(false);
				drinkorderevent(6, table);

			}
		});
		btlemade.setBackground(new Color(242, 242, 242));
		btlemade.setFont(new Font("����������", Font.PLAIN, 15));
		btlemade.setBounds(50, 230, 129, 60);
		drinkmenu.add(btlemade);
		
		JButton btgfade = new JButton("\uC790\uBABD\uC5D0\uC774\uB4DC");
		btgfade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
				
				cbshot.setEnabled(false);
				cbsyrup.setEnabled(false);
				cbwhipping.setEnabled(false);
				cbhot.setVisible(false);
				cbice.setVisible(false);
				drinkorderevent(7, table);

			}
		});
		btgfade.setBackground(new Color(242, 242, 242));
		btgfade.setFont(new Font("����������", Font.PLAIN, 15));
		btgfade.setBounds(212, 230, 129, 60);
		drinkmenu.add(btgfade);
		
		JButton btggade = new JButton("\uCCAD\uD3EC\uB3C4\uC5D0\uC774\uB4DC");
		btggade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);

				cbshot.setEnabled(false);
				cbsyrup.setEnabled(false);
				cbwhipping.setEnabled(false);
				cbhot.setVisible(false);
				cbice.setVisible(false);
				drinkorderevent(8, table);
			}

		});
		
		btggade.setBackground(new Color(242, 242, 242));
		btggade.setFont(new Font("����������", Font.PLAIN, 15));
		btggade.setBounds(374, 230, 129, 60);
		drinkmenu.add(btggade);
		
		
		JButton[] drinkmenubtn = {btame, btlatte, btmocha, btmktea, btgrntea, btstbsmd, btlemade, btgfade, btggade};
		drinkmenubtnmge = drinkmenubtn;
		
		JPanel dessertmenu = new JPanel();
		dessertmenu.setLayout(null);
		dessertmenu.setForeground(Color.WHITE);
		dessertmenu.setBackground(Color.WHITE);
		dessertmenu.setBounds(0, 0, 558, 411);
		menupn.add(dessertmenu);
		
		JButton btplwaffle = new JButton("\uD50C\uB808\uC778\uC640\uD50C");
		btplwaffle.setBounds(50, 42, 129, 60);
		dessertmenu.add(btplwaffle);
		btplwaffle.setBackground(new Color(242, 242, 242));
		btplwaffle.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton btcroissant = new JButton("\uD06C\uB8E8\uC544\uC0C1");
		btcroissant.setBounds(212, 42, 129, 60);
		dessertmenu.add(btcroissant);
		btcroissant.setBackground(new Color(242, 242, 242));
		btcroissant.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton btsandwich = new JButton("\uC0CC\uB4DC\uC704\uCE58");
		btsandwich.setBounds(374, 42, 129, 60);
		dessertmenu.add(btsandwich);
		btsandwich.setBackground(new Color(242, 242, 242));
		btsandwich.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton btrvcake = new JButton("\uB808\uB4DC\uBCA8\uBCB3\uCF00\uC775");
		btrvcake.setBounds(50, 137, 129, 60);
		dessertmenu.add(btrvcake);
		btrvcake.setBackground(new Color(242, 242, 242));
		btrvcake.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton btchcake = new JButton("\uCE58\uC988\uCF00\uC775");
		btchcake.setBounds(212, 137, 129, 60);
		dessertmenu.add(btchcake);
		btchcake.setBackground(new Color(242, 242, 242));
		btchcake.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton bttrms = new JButton("\uD2F0\uB77C\uBBF8\uC218");
		bttrms.setBounds(374, 137, 129, 60);
		dessertmenu.add(bttrms);
		bttrms.setBackground(new Color(242, 242, 242));
		bttrms.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton bthnbread = new JButton("\uD5C8\uB2C8\uBE0C\uB808\uB4DC");
		bthnbread.setBounds(50, 230, 129, 60);
		dessertmenu.add(bthnbread);
		bthnbread.setBackground(new Color(242, 242, 242));
		bthnbread.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton btchocookie = new JButton("\uCD08\uCF54\uCFE0\uD0A4");
		btchocookie.setBounds(212, 230, 129, 60);
		dessertmenu.add(btchocookie);
		btchocookie.setBackground(new Color(242, 242, 242));
		btchocookie.setFont(new Font("����������", Font.PLAIN, 15));
		
		JButton btberrybagel = new JButton("\uBE14\uB8E8\uBCA0\uB9AC\uBCA0\uC774\uAE00");
		btberrybagel.setBounds(374, 230, 129, 60);
		dessertmenu.add(btberrybagel);
		btberrybagel.setBackground(new Color(242, 242, 242));
		btberrybagel.setFont(new Font("����������", Font.PLAIN, 15));
		
		
		JButton[] dessmenubtn = {btplwaffle, btcroissant, btsandwich, btrvcake, btchcake, bttrms, bthnbread, btchocookie, btberrybagel};
		

		for(int i=0;i<9;i++) {
			int p = i;
			
			dessmenubtn[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dessclickcnt[p]++;
					dessorder.count[p]++;
					ordertotalcnt++;
					ordermenutype.add("����Ʈ");
					int extracntrow = 0;
					if(dessclickcnt[p]==1) {
						model.insertRow(table.getRowCount(), new Object[]{dessorder.name[p],dessorder.count[p]});
						ordermenu.add(dessorder.name[p]);
						ordermenucnt.add(dessorder.count[p]);
					}
					else {
						for(int j=0;j<table.getRowCount();j++)
							if(model.getValueAt(j, 0).equals(dessorder.name[p])) {
								extracntrow = j;
								model.setValueAt(dessorder.count[p], extracntrow, 1);
							}
						ordermenucnt.set(ordermenu.indexOf(dessorder.name[p]), dessorder.count[p]);
					}
					stockcnt.dessertstockcnt[0]--;
					stockcnt.dessertstockcnt[1]--;
					stockcnt.tissuecnt--;
					
				}
			});
		}
		
		dessmenubtnmge = dessmenubtn;
		
		JPanel accmenu = new JPanel();
		accmenu.setBounds(0, 0, 558, 411);
		menupn.add(accmenu);
		accmenu.setLayout(null);
		accmenu.setForeground(Color.WHITE);
		accmenu.setBackground(Color.WHITE);
		
		JButton bttumblr = new JButton("\uD140\uBE14\uB7EC");
		bttumblr.setFont(new Font("����������", Font.PLAIN, 15));
		bttumblr.setBounds(50, 42, 129, 60);
		bttumblr.setBackground(new Color(242, 242, 242));
		accmenu.add(bttumblr);
		
		JButton btmug = new JButton("\uBA38\uADF8\uCEF5");
		btmug.setFont(new Font("����������", Font.PLAIN, 15));
		btmug.setBounds(212, 42, 129, 60);
		btmug.setBackground(new Color(242, 242, 242));
		accmenu.add(btmug);
		
		JButton btplate = new JButton("\uD50C\uB808\uC774\uD2B8");
		btplate.setFont(new Font("����������", Font.PLAIN, 15));
		btplate.setBounds(374, 42, 129, 60);
		btplate.setBackground(new Color(242, 242, 242));
		accmenu.add(btplate);
		
		JButton btglass = new JButton("\uAE00\uB77C\uC2A4");
		btglass.setFont(new Font("����������", Font.PLAIN, 15));
		btglass.setBounds(50, 137, 129, 60);
		btglass.setBackground(new Color(242, 242, 242));
		accmenu.add(btglass);
		
		JButton btmuddler = new JButton("\uBA38\uB4E4\uB7EC");
		btmuddler.setFont(new Font("����������", Font.PLAIN, 15));
		btmuddler.setBounds(212, 137, 129, 60);
		btmuddler.setBackground(new Color(242, 242, 242));
		accmenu.add(btmuddler);
		
		
		JButton[] accmenubtn = {bttumblr, btmug, btplate, btglass, btmuddler};
		
		
		for(int i=0;i<5;i++) {
			int p = i;
			accmenubtn[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					accclickcnt[p]++;
					accorder.count[p]++;
					ordertotalcnt++;
					ordermenutype.add("�Ǽ��縮");
					
					int extracntrow = 0;
					if(accclickcnt[p]==1) {
						model.insertRow(table.getRowCount(), new Object[]{accorder.name[p],accorder.count[p]});
						ordermenu.add(accorder.name[p]);
						ordermenucnt.add(accorder.count[p]);
					}

					else {
						for(int j=0;j<table.getRowCount();j++)
							if(model.getValueAt(j, 0).equals(accorder.name[p])) {
								extracntrow = j;
								model.setValueAt(accorder.count[p], extracntrow, 1);
							}
						ordermenucnt.set(ordermenu.indexOf(accorder.name[p]), accorder.count[p]);
					}

				}
			});
		}
		
		stpn = new JPanel();
		stpn.setBackground(Color.WHITE);
		stpn.setBounds(20, 518, 494, 55);
		ordermanager.add(stpn);
		
		
		stocktext = new JTextArea(); // ��� ��Ȳ
		stocktext.setEditable(false);
		stocktext.setBounds(3, 5, 490, 45);
		String str=" ";
		for(int i=0;i<4;i++) {
			str = str + stockcnt.drinkstock[i] + " : " + stockcnt.drinkstockcnt[i] + "      ";
			if (i == 2)
				str = str + "\n" + " ";
		}
		str = str + stockcnt.tissuestock + " : " + stockcnt.tissuecnt;
		stpn.setLayout(null);
		stocktext.setText(str);
		stocktext.setFont(new Font("����������", Font.PLAIN, 15));
		stocktext.setColumns(10);
		stpn.add(stocktext);
		
		
		dessertbtn = new JButton("\uB514\uC800\uD2B8"); // ����Ʈ ��ư
		dessertbtn.setForeground(Color.WHITE);
		dessertbtn.setBackground(new Color(157, 195, 230));
		dessertbtn.setBounds(220, 41, 140, 46);
		ordermanager.add(dessertbtn);
		dessertbtn.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		
		drinkbtn = new JButton("\uC74C\uB8CC"); // ���� ��ư
		drinkbtn.setForeground(Color.WHITE);
		drinkbtn.setBackground(new Color(65, 150, 205));
		drinkbtn.setBounds(60, 41, 140, 46);
		ordermanager.add(drinkbtn);
		drinkbtn.setFont(new Font("���������� Bold", Font.PLAIN, 16));

		JButton accbtn = new JButton("\uC545\uC138\uC0AC\uB9AC"); // �Ǽ��縮 ��ư
		accbtn.setForeground(Color.WHITE);
		accbtn.setBackground(new Color(157, 195, 230));
		accbtn.setBounds(380, 41, 140, 46);
		ordermanager.add(accbtn);
		accbtn.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		
		drinkbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuclicked = 1;
				drinkmenu.setVisible(true);
				drinkbtn.setBackground(new Color(65, 150, 205));
				dessertmenu.setVisible(false);
				dessertbtn.setBackground(new Color(157, 195, 230));
				accmenu.setVisible(false);
				accbtn.setBackground(new Color(157, 195, 230));
				String str=" ";
				for(int i=0;i<4;i++) {
					str = str + stockcnt.drinkstock[i] + " : " + stockcnt.drinkstockcnt[i] + "      ";
					if (i == 2)
						str = str + "\n" + " ";
				}
				str = str + stockcnt.tissuestock + " : " + stockcnt.tissuecnt;
				stocktext.setText(str);
			}
		});
		
		dessertbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuclicked = 2;
				drinkmenu.setVisible(false);
				drinkbtn.setBackground(new Color(157, 195, 230));
				dessertmenu.setVisible(true);
				dessertbtn.setBackground(new Color(65, 150, 205));
				accmenu.setVisible(false);
				accbtn.setBackground(new Color(157, 195, 230));
				String str2 = " ��ũ : " + stockcnt.dessertstockcnt[0] + "\t" + "������ : " + stockcnt.dessertstockcnt[1] + "\t";
				str2 = str2 + stockcnt.tissuestock + " : " + stockcnt.tissuecnt;
				stocktext.setText(str2);
			}
		});

		accbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menuclicked = 3;
				drinkmenu.setVisible(false);
				drinkbtn.setBackground(new Color(157, 195, 230));
				dessertmenu.setVisible(false);
				dessertbtn.setBackground(new Color(157, 195, 230));
				accmenu.setVisible(true);
				accbtn.setBackground(new Color(65, 150, 205));
				stpn.setVisible(false);
				stocktext.setVisible(false);
				
			}
		});
		
		
		JButton btncancel = new JButton("\uCDE8\uC18C"); // ��� ��ư
		btncancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // �ֹ� ���
				
				for(int w=4;w<9;w++) {
					for(int p=0;p<drinkorder.count[w];p++) {
						stockcnt.drinkstockcnt[1]++;
						stockcnt.drinkstockcnt[3]++;
					}
				}
				
				for(int q=0;q<model.getRowCount();q++) {
					if(table.getValueAt(q, 0).toString().contains("HOT")) {
						for(int s = 0; s<(int)table.getValueAt(q, 1);s++) {
							stockcnt.drinkstockcnt[0]++;
							stockcnt.drinkstockcnt[2]++;
						}
	
					}
					else if(table.getValueAt(q, 0).toString().contains("ICE")) {
						for(int s = 0; s<(int)table.getValueAt(q, 1);s++) {
							stockcnt.drinkstockcnt[1]++;
							stockcnt.drinkstockcnt[3]++;
						}
					}
				}
				
				for(int i=0;i<9;i++) {
					for(int p=0;p<drinkorder.count[i];p++)
						stockcnt.tissuecnt++;
					
					drinkorder.count[i]=0;
					drinkclickcnt[i]=0;
				}
				
				for(int k=0;k<9;k++) {
					for(int p=0;p<dessorder.count[k];p++) {
						stockcnt.dessertstockcnt[0]++;
						stockcnt.dessertstockcnt[1]++;
						stockcnt.tissuecnt++;
					}
					dessorder.count[k]=0;
					dessclickcnt[k]=0;
				}
				
				for(int j=0;j<5;j++) {
					accorder.count[j]=0;
					accclickcnt[j]=0;
				}
				
				model.setRowCount(0);
				ordermenu.clear();
				ordermenucnt.clear();
				ordermenutype.clear();
				ordertotalcnt = 0;
	
			}
		});
		
		for(int i=0;i<9;i++) {
			tableorderlist[i] = new Table();
			tableorderlist[i].initTable(i+1);
		}

		
		btncancel.setForeground(Color.WHITE);
		btncancel.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		btncancel.setBackground(new Color(140, 190, 225));
		btncancel.setBounds(588, 359, 241, 48);
		ordermanager.add(btncancel);
		
		btntborder = new JButton("\uD14C\uC774\uBE14 \uC8FC\uBB38"); // ���̺��ֹ� ��ư
		btntborder.setForeground(Color.WHITE);
		btntborder.setBounds(588, 422, 241, 48);
		btntborder.setBackground(new Color(140, 190, 255));
		btntborder.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		ordermanager.add(btntborder);
		
		btntborder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tborder = new Tableorder(tablecnt, tableorderlist, ordermenu, ordermenucnt, ordermenutype, ordertotalcnt, table, model, orderdetail);
				tborder.setVisible(true);
			}
		});
		

		JButton btnextraorder = new JButton("\uCD94\uAC00 \uC8FC\uBB38");
		btnextraorder.setForeground(Color.WHITE);
		btnextraorder.setBackground(new Color(140, 190, 255));
		btnextraorder.setBounds(588, 486, 241, 48);
		btnextraorder.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		ordermanager.add(btnextraorder);
		
		btnextraorder.addActionListener(new ActionListener() { // �߰��ֹ���ư
			public void actionPerformed(ActionEvent e) {
				exorder = new Extraorder(tablecnt, tableorderlist, ordermenu, ordermenucnt, ordermenutype, ordertotalcnt, table, model, orderdetail);
				exorder.setVisible(true);
			}
		});
		
		JButton btntakeout = new JButton("\uD14C\uC774\uD06C\uC544\uC6C3"); // ����ũ�ƿ���ư
		btntakeout.setForeground(Color.WHITE);
		btntakeout.setBounds(588, 547, 241, 48);
		btntakeout.setBackground(new Color(140, 190, 255));
		ordermanager.add(btntakeout);
		btntakeout.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		
		
		
		btntakeout.addActionListener(new ActionListener() { // ����ũ�ƿ� ��ư
			public void actionPerformed(ActionEvent e) {
				SimpleDateFormat sf, sf2;
				sf = new SimpleDateFormat("yyyy-MM-dd");
				sf2 = new SimpleDateFormat("HH:mm:ss");
				Date now = new Date();
				String date = sf.format(now);
				String time = sf2.format(now);

				String saletime = date + " " + time;
				
				// ���Ͽ� ��ǰ �Ǹ� ���� ����
				PrintWriter pw = null;
				try {
		            pw = new PrintWriter(new FileWriter(file, true));
		            	for(int i=0;i<ordermenu.size();i++) {
			                pw.write(saletime + " " + ordermenu.elementAt(i) + " " + ordermenucnt.elementAt(i)+"\n");
		            	}
		                pw.close();
				} catch(IOException e1) {
					e1.printStackTrace();
					System.out.println("����� ����");
				}
				
				model.setRowCount(0);
				ordermenu.clear();
				ordermenucnt.clear();
				ordermenutype.clear();
				ordertotalcnt = 0;
				for(int a=0;a<drinkorder.count.length;a++)
					drinkorder.count[a]=0;
				for(int b=0;b<drinkclickcnt.length;b++)
					drinkclickcnt[b]=0;
				for(int i=0;i<dessorder.count.length;i++)
					dessorder.count[i]=0;
				for(int j=0;j<accorder.count.length;j++)
					accorder.count[j]=0;
				for(int k=0;k<dessclickcnt.length;k++)
					dessclickcnt[k]=0;
				for(int p=0;p<accclickcnt.length;p++)
					accclickcnt[p]=0;
				for(int k=0;k<3;k++)
					cbdrinkopt[k].setSelected(false);
				cbhot.setSelected(false);
				cbice.setSelected(false);
			}
		});

		

		// �ʱ� ȭ��
		ordermanager.setVisible(true);
		
	

		JPanel tablemanager = new JPanel();  // ���̺�����
		tablemanager.setBackground(SystemColor.inactiveCaptionBorder);
		tablemanager.setBounds(14, 15, 840, 610);
		posmain.add(tablemanager);
		tablemanager.setLayout(null);
		
		JPanel tablelist = new JPanel();
		tablelist.setLayout(null);
		tablelist.setBackground(Color.WHITE);
		tablelist.setBounds(587, 88, 241, 308);
		tablemanager.add(tablelist);
		
		JLabel lbtborderlist = new JLabel("\uD14C\uC774\uBE14 \uC8FC\uBB38 \uB0B4\uC5ED");
		lbtborderlist.setFont(new Font("���������� Bold", Font.PLAIN, 15));
		lbtborderlist.setBounds(5, 0, 235, 28);
		tablelist.add(lbtborderlist);
		
		txatborderlist = new JTextArea();
		JScrollPane tbordscrollpane = new JScrollPane(txatborderlist);
		tbordscrollpane.setBorder(null);
		tbordscrollpane.setBounds(5, 29, 235, 278);
		tablelist.add(tbordscrollpane);
		tbordscrollpane.setVisible(true);
		txatborderlist.setText("");
		txatborderlist.setEditable(false);
		txatborderlist.setBounds(5, 29, 235, 278);
		txatborderlist.setLineWrap(true);
		
		JPanel tablepn = new JPanel();
		tablepn.setBackground(Color.WHITE);
		tablepn.setBounds(18, 88, 558, 411);
		tablemanager.add(tablepn);
		tablepn.setLayout(null);
		
		tb1 = new JButton("1");
		tb1.setForeground(Color.WHITE);
		tb1.setFont(new Font("����������", Font.BOLD, 20));
		tb1.setBounds(41, 62, 129, 72);
		tb1.setBackground(new Color(90, 155, 215));
		tablepn.add(tb1);
		
		tb2 = new JButton("2");
		tb2.setForeground(Color.WHITE);
		tb2.setFont(new Font("����������", Font.BOLD, 20));
		tb2.setBounds(208, 62, 129, 72);
		tb2.setBackground(new Color(90, 155, 215));
		tablepn.add(tb2);

		tb3 = new JButton("3");
		tb3.setForeground(Color.WHITE);
		tb3.setFont(new Font("����������", Font.BOLD, 20));
		tb3.setBounds(375, 62, 129, 72);
		tb3.setBackground(new Color(90, 155, 215));
		tablepn.add(tb3);

		tb4 = new JButton("4");
		tb4.setForeground(Color.WHITE);
		tb4.setFont(new Font("����������", Font.BOLD, 20));
		tb4.setBounds(41, 157, 129, 72);
		tb4.setBackground(new Color(90, 155, 215));
		tablepn.add(tb4);

		
		tb5 = new JButton("5");
		tb5.setForeground(Color.WHITE);
		tb5.setFont(new Font("����������", Font.BOLD, 20));
		tb5.setBounds(208, 157, 129, 72);
		tb5.setBackground(new Color(90, 155, 215));
		tablepn.add(tb5);

		
		tb6 = new JButton("6");
		tb6.setForeground(Color.WHITE);
		tb6.setFont(new Font("����������", Font.BOLD, 20));
		tb6.setBounds(375, 157, 129, 72);
		tb6.setBackground(new Color(90, 155, 215));
		tablepn.add(tb6);

		tb7 = new JButton("7");
		tb7.setForeground(Color.WHITE);
		tb7.setFont(new Font("����������", Font.BOLD, 20));
		tb7.setBounds(41, 250, 129, 72);
		tb7.setBackground(new Color(90, 155, 215));
		tb7.setVisible(false);
		tablepn.add(tb7);

		
		tb8 = new JButton("8");
		tb8.setForeground(Color.WHITE);
		tb8.setFont(new Font("����������", Font.BOLD, 20));
		tb8.setBounds(208, 250, 129, 72);
		tb8.setBackground(new Color(90, 155, 215));
		tb8.setVisible(false);
		tablepn.add(tb8);

		
		tb9 = new JButton("9");
		tb9.setForeground(Color.WHITE);
		tb9.setFont(new Font("����������", Font.BOLD, 20));
		tb9.setBounds(375, 250, 129, 72);
		tb9.setBackground(new Color(90, 155, 215));
		tb9.setVisible(false);
		tablepn.add(tb9);
	
		JButton[] tablebtn_list = {tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8, tb9};
		for(int s=0;s<9;s++) {
			int p = s;
			tablebtn_list[s].addActionListener(new ActionListener() { // Ư�� ���̺� �ֹ� �� ��ȸ
				public void actionPerformed(ActionEvent e) {
					tborderlist = new Tborderlist(tableorderlist[p], orderdetail.elementAt(p));
					tborderlist.setVisible(true);
				}
			});
		}
		tablebtnlist = tablebtn_list;
		

		int q;
		for(q=0; q<9; q++) // ���̺��� ������ ����ũ�ƿ��� ����
			if(tableorderlist[q].isempty==true)
				break;
		if(q==9)
			btntborder.setEnabled(false);
		
		
		
		
		JTextField txtTable = new JTextField();
		txtTable.setEditable(false);
		txtTable.setBackground(new Color(255, 255, 255));
		txtTable.setHorizontalAlignment(SwingConstants.CENTER);
		txtTable.setFont(new Font("���������� Bold", Font.PLAIN, 20));
		txtTable.setText("Table");
		txtTable.setBounds(13, 3, 129, 37);
		tablepn.add(txtTable);
		txtTable.setColumns(10);
		
	
		JButton btncleantb = new JButton("\uD14C\uC774\uBE14 \uCE58\uC6B0\uAE30"); // ���̺� ġ��� ��ư
		btncleantb.setForeground(Color.WHITE);
		btncleantb.setBackground(new Color(140, 190, 225));
		btncleantb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cleantb.Cleantb(tableorderlist);
				cleantb.setVisible(true);
			}
		});
		btncleantb.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		btncleantb.setBounds(587, 469, 241, 48);
		tablemanager.add(btncleantb);
		
		JButton btnaddtb = new JButton("\uD14C\uC774\uBE14 \uCD94\uAC00"); // ���̺� �߰� ��ư
		btnaddtb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<9;i++) {
					if(tablebtnlist[i].isVisible()==false) {
						tablebtnlist[i].setVisible(true);
						tablecnt++;
						break;
					}
				}
				cleantb.AddTable(tablecnt); // ���̺� ġ��� â������ ������ �� �ִ� ���̺��� �߰���
			}
		});
		btnaddtb.setForeground(Color.WHITE);
		btnaddtb.setBackground(new Color(140, 190, 225));
		btnaddtb.setBounds(587, 530, 241, 48);
		tablemanager.add(btnaddtb);
		btnaddtb.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		tablemanager.setVisible(false);
        
		
		JPanel menumanager = new JPanel(); // �޴� �Ǹ� ����
		menumanager.setBounds(14, 15, 840, 610);
		posmain.add(menumanager);
		menumanager.setBackground(SystemColor.inactiveCaptionBorder);
		menumanager.setLayout(null);
		
		JPanel drinkmge = new JPanel();
		drinkmge.setLayout(null);
		drinkmge.setForeground(Color.WHITE);
		drinkmge.setBackground(Color.WHITE);
		drinkmge.setBounds(134, 126, 558, 411);
		menumanager.add(drinkmge);
		
		JCheckBox cbame = new JCheckBox("\uC544\uBA54\uB9AC\uCE74\uB178");
		cbame.setSelected(true);
		
		cbame.setFont(new Font("����������", Font.PLAIN, 15));
		cbame.setBounds(50, 90, 132, 50);
		drinkmge.add(cbame);
		
		JCheckBox cblatte = new JCheckBox("\uCE74\uD398\uB77C\uB5BC");
		cblatte.setSelected(true);
		cblatte.setFont(new Font("����������", Font.PLAIN, 15));
		cblatte.setBounds(215, 90, 132, 50);
		drinkmge.add(cblatte);
		
		JCheckBox cbmocha_1 = new JCheckBox("\uCE74\uD398\uBAA8\uCE74");
		cbmocha_1.setSelected(true);
		cbmocha_1.setFont(new Font("����������", Font.PLAIN, 15));
		cbmocha_1.setBounds(375, 90, 132, 50);
		drinkmge.add(cbmocha_1);
		
		JCheckBox cbmktea = new JCheckBox("\uBC00\uD06C\uD2F0");
		cbmktea.setSelected(true);
		cbmktea.setFont(new Font("����������", Font.PLAIN, 15));
		cbmktea.setBounds(50, 178, 132, 50);
		drinkmge.add(cbmktea);
		
		JCheckBox cbgrntea = new JCheckBox("\uADF8\uB9B0\uD2F0\uD504\uB77C\uD478\uCE58\uB178");
		cbgrntea.setSelected(true);
		cbgrntea.setFont(new Font("����������", Font.PLAIN, 13));
		cbgrntea.setBounds(215, 178, 132, 50);
		drinkmge.add(cbgrntea);
		
		JCheckBox cbstbsmd = new JCheckBox("\uB538\uAE30\uC2A4\uBB34\uB514");
		cbstbsmd.setSelected(true);
		cbstbsmd.setFont(new Font("����������", Font.PLAIN, 15));
		cbstbsmd.setBounds(375, 178, 132, 50);
		drinkmge.add(cbstbsmd);
		
		JCheckBox cblemade = new JCheckBox("\uB808\uBAAC\uC5D0\uC774\uB4DC");
		cblemade.setSelected(true);
		cblemade.setFont(new Font("����������", Font.PLAIN, 15));
		cblemade.setHorizontalAlignment(SwingConstants.LEFT);
		cblemade.setBounds(50, 265, 132, 50);
		drinkmge.add(cblemade);
		
		JCheckBox cbgfade = new JCheckBox("\uC790\uBABD\uC5D0\uC774\uB4DC");
		cbgfade.setSelected(true);
		cbgfade.setFont(new Font("����������", Font.PLAIN, 15));
		cbgfade.setBounds(215, 265, 132, 50);
		drinkmge.add(cbgfade);
		
		JCheckBox cbggade = new JCheckBox("\uCCAD\uD3EC\uB3C4\uC5D0\uC774\uB4DC");
		cbggade.setSelected(true);
		cbggade.setFont(new Font("����������", Font.PLAIN, 15));
		cbggade.setBounds(375, 265, 132, 50);
		drinkmge.add(cbggade);
		
		JPanel accmge = new JPanel();
		accmge.setLayout(null);
		accmge.setForeground(Color.WHITE);
		accmge.setBackground(Color.WHITE);
		accmge.setBounds(134, 126, 558, 411);
		menumanager.add(accmge);
		
		JCheckBox cbtumblr = new JCheckBox("\uD140\uBE14\uB7EC");
		cbtumblr.setSelected(true);
		cbtumblr.setFont(new Font("����������", Font.PLAIN, 15));
		cbtumblr.setBounds(50, 90, 132, 50);
		accmge.add(cbtumblr);
		
		JCheckBox cbmug = new JCheckBox("\uBA38\uADF8\uCEF5");
		cbmug.setSelected(true);
		cbmug.setFont(new Font("����������", Font.PLAIN, 15));
		cbmug.setBounds(215, 90, 132, 50);
		accmge.add(cbmug);
		
		JCheckBox cbplate = new JCheckBox("\uD50C\uB808\uC774\uD2B8");
		cbplate.setSelected(true);
		cbplate.setFont(new Font("����������", Font.PLAIN, 15));
		cbplate.setBounds(375, 90, 132, 50);
		accmge.add(cbplate);
		
		JCheckBox cbglass = new JCheckBox("\uAE00\uB77C\uC2A4");
		cbglass.setSelected(true);
		cbglass.setFont(new Font("����������", Font.PLAIN, 15));
		cbglass.setBounds(50, 178, 132, 50);
		accmge.add(cbglass);
		
		JCheckBox cbmuddler = new JCheckBox("\uBA38\uB4E4\uB7EC");
		cbmuddler.setSelected(true);
		cbmuddler.setFont(new Font("����������", Font.PLAIN, 15));
		cbmuddler.setBounds(215, 178, 132, 50);
		accmge.add(cbmuddler);
		
		JPanel dessertmge = new JPanel();
		dessertmge.setLayout(null);
		dessertmge.setForeground(Color.WHITE);
		dessertmge.setBackground(Color.WHITE);
		dessertmge.setBounds(134, 126, 558, 411);
		menumanager.add(dessertmge);
		
		JCheckBox cbplwaffle = new JCheckBox("\uD50C\uB808\uC778\uC640\uD50C");
		cbplwaffle.setSelected(true);
		cbplwaffle.setFont(new Font("����������", Font.PLAIN, 15));
		cbplwaffle.setBounds(50, 90, 132, 50);
		dessertmge.add(cbplwaffle);
		
		JCheckBox cbcroissant = new JCheckBox("\uD06C\uB8E8\uC544\uC0C1");
		cbcroissant.setSelected(true);
		cbcroissant.setFont(new Font("����������", Font.PLAIN, 15));
		cbcroissant.setBounds(215, 90, 132, 50);
		dessertmge.add(cbcroissant);
		
		JCheckBox cbsandwich = new JCheckBox("\uC0CC\uB4DC\uC704\uCE58");
		cbsandwich.setSelected(true);
		cbsandwich.setFont(new Font("����������", Font.PLAIN, 15));
		cbsandwich.setBounds(375, 90, 132, 50);
		dessertmge.add(cbsandwich);
		
		JCheckBox cbrvcake = new JCheckBox("\uB808\uB4DC\uBCA8\uBCB3\uCF00\uC775");
		cbrvcake.setSelected(true);
		cbrvcake.setFont(new Font("����������", Font.PLAIN, 15));
		cbrvcake.setBounds(50, 178, 132, 50);
		dessertmge.add(cbrvcake);
		
		JCheckBox cbchcake = new JCheckBox("\uCE58\uC988\uCF00\uC775");
		cbchcake.setSelected(true);
		cbchcake.setFont(new Font("����������", Font.PLAIN, 15));
		cbchcake.setBounds(215, 178, 132, 50);
		dessertmge.add(cbchcake);
		
		JCheckBox cbtrms = new JCheckBox("\uD2F0\uB77C\uBBF8\uC218");
		cbtrms.setSelected(true);
		cbtrms.setFont(new Font("����������", Font.PLAIN, 15));
		cbtrms.setBounds(375, 178, 132, 50);
		dessertmge.add(cbtrms);
		
		JCheckBox cbhnbread = new JCheckBox("\uD5C8\uB2C8\uBE0C\uB808\uB4DC");
		cbhnbread.setSelected(true);
		cbhnbread.setFont(new Font("����������", Font.PLAIN, 15));
		cbhnbread.setHorizontalAlignment(SwingConstants.LEFT);
		cbhnbread.setBounds(50, 265, 132, 50);
		dessertmge.add(cbhnbread);
		
		JCheckBox cbchocookie = new JCheckBox("\uCD08\uCF54\uCFE0\uD0A4");
		cbchocookie.setSelected(true);
		cbchocookie.setFont(new Font("����������", Font.PLAIN, 15));
		cbchocookie.setBounds(215, 265, 132, 50);
		dessertmge.add(cbchocookie);
		
		JCheckBox cbberrybagel = new JCheckBox("\uBE14\uB8E8\uBCA0\uB9AC \uBCA0\uC774\uAE00");
		cbberrybagel.setSelected(true);
		cbberrybagel.setFont(new Font("����������", Font.PLAIN, 15));
		cbberrybagel.setBounds(375, 265, 132, 50);
		dessertmge.add(cbberrybagel);
		
		
		JButton btdrinkmge = new JButton("\uC74C\uB8CC"); // ���� ���� ��ư
		btdrinkmge.setForeground(Color.WHITE);
		btdrinkmge.setBackground(new Color(65, 150, 205));
		btdrinkmge.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		btdrinkmge.setBounds(187, 81, 140, 46);
		menumanager.add(btdrinkmge);
		
		JButton btdessertmge = new JButton("\uB514\uC800\uD2B8"); // ����Ʈ ���� ��ư
		btdessertmge.setForeground(Color.WHITE);
		btdessertmge.setBackground(new Color(157, 195, 230));
		btdessertmge.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		btdessertmge.setBounds(341, 81, 140, 46);
		menumanager.add(btdessertmge);
		
		JButton btaccmge = new JButton("\uC545\uC138\uC0AC\uB9AC"); // �Ǽ��縮 ���� ��ư
		btaccmge.setForeground(Color.WHITE);
		btaccmge.setBackground(new Color(157, 195, 230));
		btaccmge.setFont(new Font("���������� Bold", Font.PLAIN, 16));
		btaccmge.setBounds(494, 81, 140, 46);
		menumanager.add(btaccmge);
		
		JLabel lbmenumge = new JLabel("\uD310\uB9E4 \uC124\uC815");
		lbmenumge.setFont(new Font("����������", Font.BOLD, 22));
		lbmenumge.setBounds(56, 29, 120, 46);
		menumanager.add(lbmenumge);
		
		
		
		menumanager.setVisible(false);
		
		btdrinkmge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drinkmge.setVisible(true);
				btdrinkmge.setBackground(new Color(65, 150, 205));
				dessertmge.setVisible(false);
				btdessertmge.setBackground(new Color(157, 195, 230));
				accmge.setVisible(false);
				btaccmge.setBackground(new Color(157, 195, 230));
			}
		});
		
		btdessertmge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drinkmge.setVisible(false);
				btdrinkmge.setBackground(new Color(157, 195, 230));
				dessertmge.setVisible(true);
				btdessertmge.setBackground(new Color(65, 150, 205));
				accmge.setVisible(false);
				btaccmge.setBackground(new Color(157, 195, 230));
			}
		});
		btaccmge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drinkmge.setVisible(false);
				btdrinkmge.setBackground(new Color(157, 195, 230));
				dessertmge.setVisible(false);
				btdessertmge.setBackground(new Color(157, 195, 230));
				accmge.setVisible(true);
				btaccmge.setBackground(new Color(65, 150, 205));
			}
		});
		

		JCheckBox cbmenu[] = {cbame, cblatte, cbmocha_1, cbmktea, cbgrntea, cbstbsmd, cblemade, cbgfade, cbggade,
				cbplwaffle, cbcroissant, cbsandwich, cbrvcake, cbchcake, cbtrms, cbhnbread, cbchocookie, cbberrybagel,
				cbtumblr, cbmug, cbplate, cbglass, cbmuddler};

		JButton btmenu[] = {btame, btlatte, btmocha, btmktea, btgrntea, btstbsmd, btlemade, btgfade, btggade,
				btplwaffle, btcroissant, btsandwich, btrvcake, btchcake, bttrms, bthnbread, btchocookie, btberrybagel,
				bttumblr, btmug, btplate, btglass, btmuddler};
		
		for(int i=0;i<23;i++) { // �޴� �Ǹ� ����
			int k = i;
			cbmenu[k].addItemListener(new ItemListener() {
			    public void itemStateChanged(ItemEvent e) {
			    	if(e.getStateChange()==1)
			    		btmenu[k].setEnabled(true);
			    	else
			    		btmenu[k].setEnabled(false);
			    }
			});
		}
		

		orderbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ordermanager.setVisible(true);
				orderbtn.setBackground(new Color(45, 110, 170));
				stockbtn.setBackground(new Color(90,155,215));
				tablemanager.setVisible(false);
				tablebtn.setBackground(new Color(90,155,215));
				menumanager.setVisible(false);
				menubtn.setBackground(new Color(90,155,215));

			}
		});
		tablebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ordermanager.setVisible(false);
				orderbtn.setBackground(new Color(90,155,215));
				tablemanager.setVisible(true);
				tablebtn.setBackground(new Color(45, 110, 170));
				menumanager.setVisible(false);
				menubtn.setBackground(new Color(90,155,215));
				stockbtn.setBackground(new Color(90,155,215));
			}
		});
		menubtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ordermanager.setVisible(false);
				orderbtn.setBackground(new Color(90,155,215));
				tablemanager.setVisible(false);
				tablebtn.setBackground(new Color(90,155,215));
				menumanager.setVisible(true);
				menubtn.setBackground(new Color(45, 110, 170));
				stockbtn.setBackground(new Color(90,155,215));
			}
		});
		stockbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StockManager stockmanager =  new StockManager(stockcnt);
				stockmanager.setVisible(true);
			}
		});
		salesbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SalesHistory saleshistory = new SalesHistory();
				saleshistory.setVisible(true);
			}
		});
		ordermanager.setVisible(true);
		
		if(thread == null) {
			thread = new Thread(this);
			thread.start();
		}
		
		TimeLabel1 = new JLabel();
		TimeLabel1.setText("");
		TimeLabel1.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		TimeLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
		TimeLabel1.setBounds(866, 60, 195, 35);
		posmain.add(TimeLabel1);
		TimeLabel2 = new JLabel();
		TimeLabel2.setText("");
		TimeLabel2.setFont(new Font("���������� Bold", Font.PLAIN, 18));
		TimeLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
		TimeLabel2.setBounds(866, 85, 195, 35);
		posmain.add(TimeLabel2);
	}
	
	void drinkorderevent(int p, JTable table) {
		drinkclickcnt[p]++;
		drinkorder.count[p]++;
		ordertotalcnt++;
		ordermenutype.add("����");
		
		int extracntrow = 0;
		if(drinkclickcnt[p]==1) {
			model.insertRow(table.getRowCount(), new Object[]{drinkorder.name[p],drinkorder.count[p]});
			ordermenu.add(drinkorder.name[p]);
			ordermenucnt.add(drinkorder.count[p]);
		}

		else {
			if(p<4)
				model.insertRow(table.getRowCount(), new Object[]{drinkorder.name[p], 1});
			else {
				for(int j=0;j<table.getRowCount();j++)
					if(model.getValueAt(j, 0).equals(drinkorder.name[p])) {
						extracntrow = j;
						model.setValueAt(drinkorder.count[p], extracntrow, 1);
					}
				ordermenucnt.set(ordermenu.indexOf(drinkorder.name[p]), drinkorder.count[p]);
			}
		}
		if(p>3) { // ice �ɼǸ� ������ ���ῡ ���ؼ� ��� ����
			stockcnt.drinkstockcnt[1]--;
			stockcnt.drinkstockcnt[3]--;
		}

		stockcnt.tissuecnt--;
	}
	
	void hoticeoptevent(JTable table) { // hot or ice �ɼ� ���� ��
		if(cbice.isSelected()) {
			boolean result = false;
			String menuname = "";
			model.setValueAt(model.getValueAt(model.getRowCount()-1, 0)+"(ICE)", model.getRowCount()-1, 0);
			for(int j=0;j<table.getRowCount();j++) {	
				for(int k=0;k<model.getRowCount();k++)
					if(model.getValueAt(model.getRowCount()-1, 0).toString().startsWith(model.getValueAt(k, 0).toString()))
						model.setValueAt(model.getValueAt(k, 0), model.getRowCount()-1, 0);
			}

			stockcnt.drinkstockcnt[1]--;
			stockcnt.drinkstockcnt[3]--;
		}
		else if(cbhot.isSelected()) {
			boolean result = false;
			model.setValueAt(model.getValueAt(model.getRowCount()-1, 0)+"(HOT)", model.getRowCount()-1, 0);
			for(int j=0;j<table.getRowCount();j++) {
				
				for(int k=0;k<model.getRowCount();k++)
					if(model.getValueAt(model.getRowCount()-1, 0).toString().startsWith(model.getValueAt(k, 0).toString()))
						model.setValueAt(model.getValueAt(k, 0), model.getRowCount()-1, 0);
			}
			
			stockcnt.drinkstockcnt[0]--;
			stockcnt.drinkstockcnt[2]--;
		}
		
	}
	
	
	public void run(){
		SimpleDateFormat sf, sf2;
		sf = new SimpleDateFormat("yyyy-MM-dd");
		sf2 = new SimpleDateFormat("HH:mm:ss");

		while(true){
			// �ð� ���
			Date now = new Date();
			String date = sf.format(now);
			String time = sf2.format(now);
			TimeLabel1.setText(date);
			TimeLabel2.setText(time);

			if(tborder.orderok==true) { // ���̺��� �ֹ��� �޾�����
				AfterTbOrder();
				showTableList();
			}
			
			if(exorder.orderok==true) { // �ֹ������� �ִ� ���̺��� �߰��ֹ��� �޾�����
				tablebtnlist[exorder.tablenum-1].setBackground(new Color(90, 155, 215));
				AfterTbOrder();
				showTableList();
			}

			for(int i=0; i<9; i++) {
				if(eatendcnt[i]<tableorderlist[i].ordermenustate.size()) {
					StartEating(i);
				if(eatendcnt[i]==tableorderlist[i].ordermenustate.size())
					tablebtnlist[i].setBackground(new Color(255, 250, 150));
				}
				if(cleantb.cleanok==true) { // ���̺� ���� ��
					tablebtnlist[cleantb.selected].setBackground(new Color(90, 155, 215));
					tableorderlist[cleantb.selected].resettable();
					orderdetail.elementAt(cleantb.selected).clear();
					btntborder.setBackground(new Color(140, 190, 255));
					btntborder.setEnabled(true);
					showTableList();
					eatendcnt[cleantb.selected]=0;
					cleantb.cleanok=false;
				}
			}
			
			int f;
			for(f=0; f<6; f++) {
				if(tableorderlist[f].ordermenuname.size()==0)
					break;
			}
			if(f==6) {
				btntborder.setEnabled(false);
				btntborder.setBackground(new Color(242, 242, 242)); // ���̺��� �� á�� �� ���̺��ֹ� ��ư ��Ȱ��ȭ
			}
				
			ShowStock();
			
		try{
			Thread.sleep(1000);
			} catch(Exception e) {}
		}
	}
	
	public void StartEating(int i) { // ���� ����

		for(int j=0;j<tableorderlist[i].ordermenuname.size();j++) {
			if(tableorderlist[i].ordermenustate.elementAt(j)>=0){
				Random random = new Random();
				tableorderlist[i].ordermenustate.set(j, tableorderlist[i].ordermenustate.elementAt(j)-(random.nextInt(10)+5));
				if((!tableorderlist[i].ordermenutype.elementAt(j).equals("�Ǽ��縮")) && tableorderlist[i].ordermenustate.elementAt(j)>=0) {
					System.out.println(tableorderlist[i].ordermenuname.elementAt(j) + " : " + tableorderlist[i].ordermenustate.elementAt(j));
				}
			}
			if(tableorderlist[i].ordermenustate.elementAt(j)<=0) {
				tableorderlist[i].ordermenustate.set(j, 0);
				System.out.println(tableorderlist[i].ordermenuname.elementAt(j) + " : " + tableorderlist[i].ordermenustate.elementAt(j));
			}
			int k;
			for(k=0;k<tableorderlist[i].ordermenustate.size();k++) {
				if(tableorderlist[i].ordermenustate.elementAt(k)>0)
					break;
			}
			if(k==tableorderlist[i].ordermenustate.size())
				eatendcnt[i]=tableorderlist[i].ordermenustate.size();
		}
	}
	
	public void AfterTbOrder() { // ���̺� �ֹ� �Ϸ� ��
		for(int k=0;k<3;k++)
			cbdrinkopt[k].setSelected(false);
		cbhot.setSelected(false);
		cbice.setSelected(false);
		
		// �Ǹų��� ���
		SimpleDateFormat sf, sf2;
		sf = new SimpleDateFormat("yyyy-MM-dd");
		sf2 = new SimpleDateFormat("HH:mm:ss");
		Date now = new Date();
		String date = sf.format(now);
		String time = sf2.format(now);

		String saletime = date + " " + time;
		
		// ���Ͽ� ��ǰ �Ǹ� ���� ���� 
		PrintWriter pw = null;
		try {
            pw = new PrintWriter(new FileWriter(file, true));
            	for(int i=0;i<ordermenu.size();i++) {
	                pw.write(saletime + " " + ordermenu.elementAt(i) + " " + ordermenucnt.elementAt(i)+"\n");
            	}
                pw.close();
		} catch(IOException e1) {
			e1.printStackTrace();
			System.out.println("����� ����");
		}
		
		// �ֹ����� �ʱ�ȭ
		model.setRowCount(0);
		tborder.orderok = false;
		exorder.orderok = false;
		ordermenu.clear();
		ordermenucnt.clear();
		ordermenutype.clear();
		ordertotalcnt = 0;
		for(int a=0;a<drinkorder.count.length;a++)
			drinkorder.count[a]=0;
		for(int b=0;b<drinkclickcnt.length;b++)
			drinkclickcnt[b]=0;
		for(int i=0;i<dessorder.count.length;i++)
			dessorder.count[i]=0;
		for(int j=0;j<accorder.count.length;j++)
			accorder.count[j]=0;
		for(int k=0;k<dessclickcnt.length;k++)
			dessclickcnt[k]=0;
		for(int p=0;p<accclickcnt.length;p++)
			accclickcnt[p]=0;
		showTableList();
	}
	
	public void showTableList() { // ���̺� �ֹ����� ����Ʈ ������ ���·� ǥ��
		String tborderlist = "";
		for(int i=0;i<9;i++) {
			if(tableorderlist[i].ordermenuname.size()!=0)
			{
				tborderlist += "���̺� " + tableorderlist[i].tablenum + "\n";
				for(int j=0;j<tableorderlist[i].ordermenuname.size();j++) {
					tborderlist = tborderlist + tableorderlist[i].ordermenuname.elementAt(j) + "(" + tableorderlist[i].ordermenucnt.elementAt(j) + ")"; 
					if(j!=tableorderlist[i].ordermenuname.size()-1)
						tborderlist += ", ";
				}
				tborderlist += "\n";
			}
		}
		txatborderlist.setText(tborderlist);
	}
	public void ShowStock() { // �ֹ��ϱ� ȭ�鿡�� ��� ���� �ǽð� �����ֱ�
		String str=" ";
		if(stockcnt.tissuecnt<=0)
			stockcnt.tissuecnt = 0;
			
		for(int i=0;i<4;i++) {
			str = str + stockcnt.drinkstock[i] + " : " + stockcnt.drinkstockcnt[i] + "      ";
			if (i == 2)
				str = str + "\n" + " ";
		}
		str = str + stockcnt.tissuestock + " : " + stockcnt.tissuecnt;
		
		String str2 = " ��ũ : " + stockcnt.dessertstockcnt[0] + "\t" + "������ : " + stockcnt.dessertstockcnt[1] + "\t";
		str2 = str2 + stockcnt.tissuestock + " : " + stockcnt.tissuecnt;
		
		switch(menuclicked) {
		case 1:
			stocktext.setText(str);
			stpn.setVisible(true);
			stocktext.setVisible(true);
			break;
		case 2:
			stocktext.setText(str2);
			stpn.setVisible(true);
			stocktext.setVisible(true);
			break;
		case 3:
			break;
		}
		
		// ���� �Ҹ�ǰ ����� ���� ��
		if(stockcnt.drinkstockcnt[0]==0 && stockcnt.drinkstockcnt[2]==0)
			cbhot.setEnabled(false);
		else
			cbhot.setEnabled(true);
		
		if(stockcnt.drinkstockcnt[1]==0 && stockcnt.drinkstockcnt[3]==0) {
			cbice.setEnabled(false);
			for(int i=4;i<9;i++)
				drinkmenubtnmge[i].setEnabled(false);
		}
		else{
			cbice.setEnabled(true);
			for(int i=4;i<9;i++)
				drinkmenubtnmge[i].setEnabled(true);
		}
		
		if((stockcnt.drinkstockcnt[0]==0 && stockcnt.drinkstockcnt[2]==0) && (stockcnt.drinkstockcnt[1]==0 && stockcnt.drinkstockcnt[3]==0))
			for(int i=0;i<4;i++)
				drinkmenubtnmge[i].setEnabled(false);
		
		// ����Ʈ �Ҹ�ǰ ����� ���� ��
		for(int p=0;p<2;p++) {
			if(stockcnt.dessertstockcnt[p]==0) {
				for(int j=0;j<9;j++)
					dessmenubtnmge[j].setEnabled(false);
			}
			else
				for(int j=0;j<9;j++)
					dessmenubtnmge[j].setEnabled(true);
		}
	}
}
