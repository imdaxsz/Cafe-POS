import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.util.*;

public class TbItemDetail extends JFrame{

	private JPanel contentPane;
	private JTextField itemtypetxt;
	private JTextField tablenumtxt;
	private JTextField itemstatetxt;
	private JLabel lbitemname;
	private JLabel lbmenutype;
	private JLabel lbtable;
	private JLabel lbstate;
	
	public int state;
	public String type = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TbItemDetail frame = new TbItemDetail();
					//TbItemDetail frame = new TbItemDetail();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TbItemDetail(){
	};
	//String itemname, String itemtype, int tablenum
	
	// ���̺��� Ư�� �޴��� �� ���� ���
	public void SetTbItemDetail(String itemname, String itemtype, int itemstate, int tablenum) { 
		state = itemstate;
		setTitle("\uC0C1\uD488 \uC0C1\uD0DC");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 345);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaptionBorder);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnitemok = new JButton("\uD655\uC778");
		btnitemok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		btnitemok.setFont(new Font("����������", Font.PLAIN, 15));
		btnitemok.setBackground(new Color(242, 242, 242));
		btnitemok.setBounds(170, 244, 90, 23);
		contentPane.add(btnitemok);
		
		lbitemname = new JLabel("\uC0C1\uD488 \uC774\uB984");
		lbitemname.setForeground(new Color(0, 0, 128));
		lbitemname.setHorizontalAlignment(SwingConstants.CENTER);
		lbitemname.setBounds(69, 24, 288, 54);
		contentPane.add(lbitemname);
		lbitemname.setFont(new Font("����������", Font.BOLD, 22));
		
		lbmenutype = new JLabel("Ÿ��");
		lbmenutype.setHorizontalAlignment(SwingConstants.CENTER);
		lbmenutype.setForeground(new Color(0, 102, 153));
		lbmenutype.setFont(new Font("����������", Font.BOLD, 18));
		lbmenutype.setBounds(41, 97, 72, 30);
		contentPane.add(lbmenutype);
		
		lbtable = new JLabel("\uD14C\uC774\uBE14");
		lbtable.setHorizontalAlignment(SwingConstants.CENTER);
		lbtable.setForeground(new Color(0, 102, 153));
		lbtable.setFont(new Font("����������", Font.BOLD, 18));
		lbtable.setBounds(41, 140, 72, 30);
		contentPane.add(lbtable);
		
		lbstate = new JLabel("\uC0C1\uD0DC");
		lbstate.setHorizontalAlignment(SwingConstants.CENTER);
		lbstate.setForeground(new Color(0, 102, 153));
		lbstate.setFont(new Font("����������", Font.BOLD, 18));
		lbstate.setBounds(41, 182, 72, 30);
		contentPane.add(lbstate);
		
		itemtypetxt = new JTextField();
		itemtypetxt.setEditable(false);
		itemtypetxt.setBounds(123, 98, 193, 30);
		contentPane.add(itemtypetxt);
		itemtypetxt.setColumns(10);
		
		
		tablenumtxt = new JTextField();
		tablenumtxt.setEditable(false);
		tablenumtxt.setColumns(10);
		tablenumtxt.setBounds(123, 140, 193, 30);
		contentPane.add(tablenumtxt);
		
		itemstatetxt = new JTextField();
		itemstatetxt.setEditable(false);
		itemstatetxt.setColumns(10);
		itemstatetxt.setBounds(123, 182, 193, 30);
		type = itemtype;
		lbitemname.setText(itemname);
		itemtypetxt.setText(itemtype);
		tablenumtxt.setText(Integer.toString(tablenum));
		
		if(itemtype.equals("�Ǽ��縮")) // �Ǽ��縮�� ���� ���� '�Ϸ�'�� ó��
			itemstatetxt.setText("�Ϸ�");
		else
			itemstatetxt.setText(Integer.toString(state));
		contentPane.add(itemstatetxt);

	}

}
