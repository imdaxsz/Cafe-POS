import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionEvent;

public class Tborderlist extends JFrame implements MouseListener{
	Drink drink = new Drink();
	Dessert dessert = new Dessert();
	Accessory acc = new Accessory();
	public Vector <String> detail = new Vector<String>();
	
	boolean isempty = false;
	String []a = {"��ǰ��","�ɼ�"};
	int state = 100;
	int tbnum = 0;
    DefaultTableModel model = new DefaultTableModel(a, 0) {
    	public boolean isCellEditable(int rowIndex, int mColIndex) {
    		return false;
    	}
    };
    JTable table = new JTable(model);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tborderlist frame = new Tborderlist();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Tborderlist() {};

	// Ư�� ���̺� �ֹ� �� ��ȸ
	public Tborderlist(Table tableinfo, Vector<String> orderdetail) {
		for(int i=0;i<orderdetail.size();i++) {
			detail.add(orderdetail.elementAt(i));
		}
		TbItemDetail[] itemdetail = new TbItemDetail[tableinfo.ordermenuname.size()];
		for(int i=0;i<tableinfo.ordermenuname.size();i++) {
			itemdetail[i] = new TbItemDetail();
		}
		isempty = tableinfo.isempty;
		tbnum = tableinfo.tablenum;
		setTitle("\uC0C1\uC138 \uC8FC\uBB38\uB0B4\uC5ED");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		JPanel tbinfo = new JPanel();
		tbinfo.setBackground(SystemColor.inactiveCaptionBorder);
		tbinfo.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(tbinfo);
		tbinfo.setLayout(null);
		
		JButton decancelbtn = new JButton("\uCDE8\uC18C"); // ��� ��ư
		decancelbtn.setFont(new Font("����������", Font.PLAIN, 14));
		decancelbtn.setBounds(172, 344, 91, 23);
		decancelbtn.setBackground(new Color(242, 242, 242));
		tbinfo.add(decancelbtn);
		decancelbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton detailokbtn = new JButton("\uD655\uC778"); // Ȯ�� ��ư
		detailokbtn.setFont(new Font("����������", Font.PLAIN, 14));
		detailokbtn.setBounds(302, 344, 91, 23);
		detailokbtn.setBackground(new Color(242, 242, 242));
		tbinfo.add(detailokbtn);
		detailokbtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JLabel lbtablenum = new JLabel("���̺� " + tableinfo.tablenum);
		lbtablenum.setForeground(new Color(0, 0, 128));
		lbtablenum.setFont(new Font("����������", Font.BOLD, 20));
		lbtablenum.setBounds(42, 25, 91, 29);
		tbinfo.add(lbtablenum);

        table.getColumnModel().getColumn(0).setPreferredWidth(120);  
        table.getColumnModel().getColumn(0).setResizable(false);
        table.getColumnModel().getColumn(1).setPreferredWidth(30);
        table.getColumnModel().getColumn(1).setResizable(false);
        table.getTableHeader().setReorderingAllowed(false);
        JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(123, 84, 323, 230);
		tbinfo.add(scrollPane);
		scrollPane.setViewportView(table);
		table.setBackground(Color.WHITE);
		
		int optidx = 0;
		
        for(int q = 0; q<detail.size();q++) {
        	if(!detail.elementAt(q).startsWith("+")) {
        		optidx = model.getRowCount();
        		model.insertRow(model.getRowCount(), new Object[] {detail.elementAt(q),""});
        	}
        	else
        		model.setValueAt(model.getValueAt(optidx, 1).toString() + " " + detail.elementAt(q), optidx, 1);
        }

        table.updateUI();
		
		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){ // Ư�� �޴� ���� ��
				if(e.getClickCount() == 2)
				{
					String namestr = table.getValueAt(table.getSelectedRow(), 0).toString();
					String typestr = "";
					for(int a=0;a<drink.name.length;a++) {
						if(namestr.startsWith(drink.name[a])) {
							typestr = "����";
							break;
						}
						else if(namestr.equals(dessert.name[a])) {
							typestr = "����Ʈ";
							break;
						}
					}
					for(int b=0;b<acc.name.length;b++) {
						if(namestr.equals(acc.name[b])) {
							typestr = "�Ǽ��縮";
							break;
						}
					}
					
					int idx = table.getSelectedRow();
					for(int i=0;i<tableinfo.ordermenuname.size();i++) {
						if(table.getValueAt(idx, 0).toString().startsWith(tableinfo.ordermenuname.elementAt(i))) {
							idx = i;
							break;
						}
					}
					itemdetail[idx].SetTbItemDetail(namestr, typestr, tableinfo.ordermenustate.elementAt(idx), 1);
					itemdetail[idx].setVisible(true);
				}
			}
		});
	}
	
	public void mousePressed(MouseEvent e) {};
	public void mouseEntered(MouseEvent e) {};
	public void mouseReleased(MouseEvent e) {};
	public void mouseExited(MouseEvent e) {};
	
	
}
