import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Administrator extends JFrame {

	private JPanel contentPane;
	private final JTextField TxtfieldID = new JTextField();
	private JTextField TxtfieldPW;
	
	Member member = new Member();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Administrator frame = new Administrator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Administrator() {
		setTitle("\uB85C\uADF8\uC778");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 477, 355);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaptionBorder);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbID = new JLabel("ID");
		lbID.setHorizontalAlignment(SwingConstants.CENTER);
		lbID.setForeground(SystemColor.controlDkShadow);
		lbID.setFont(new Font("���������� Bold", Font.PLAIN, 25));
		lbID.setBounds(26, 120, 68, 35);
		contentPane.add(lbID);
		TxtfieldID.setFont(new Font("����������", Font.PLAIN, 15));
		TxtfieldID.setBounds(97, 120, 231, 35);
		contentPane.add(TxtfieldID);
		TxtfieldID.setColumns(10);
		
		TxtfieldPW = new JTextField();
		TxtfieldPW.setFont(new Font("����������", Font.PLAIN, 15));
		TxtfieldPW.setColumns(10);
		TxtfieldPW.setBounds(97, 164, 231, 35);
		contentPane.add(TxtfieldPW);
		
		JLabel lblPW = new JLabel("PW");
		lblPW.setHorizontalAlignment(SwingConstants.CENTER);
		lblPW.setForeground(SystemColor.controlDkShadow);
		lblPW.setFont(new Font("���������� Bold", Font.PLAIN, 25));
		lblPW.setBounds(25, 165, 68, 35);
		contentPane.add(lblPW);
		
		JLabel lbtitle = new JLabel("Cafe POS");
		lbtitle.setForeground(new Color(25, 25, 112));
		lbtitle.setFont(new Font("���������� Bold", Font.PLAIN, 30));
		lbtitle.setHorizontalAlignment(SwingConstants.CENTER);
		lbtitle.setBounds(116, 33, 223, 49);
		contentPane.add(lbtitle);
		
		JButton btnlogin = new JButton("\uB85C\uADF8\uC778");
		btnlogin.setForeground(Color.WHITE);
		btnlogin.setBackground(new Color(140, 190, 255));
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				member.login(TxtfieldID.getText(), TxtfieldPW.getText()); // �α���
				if(member.loginresult==true) { // ���� ��
					CafePOS cafepos = new CafePOS(member.memberposition, member.membername);
					cafepos.setVisible(true);
				}
				else {
					JOptionPane mgscomplete=new JOptionPane();
					mgscomplete.showMessageDialog(null, "�ش��ϴ� ������ �����ϴ�.", "�α���", JOptionPane.INFORMATION_MESSAGE);
				}
					
			}
		});
		btnlogin.setFont(new Font("����������", Font.BOLD, 15));
		btnlogin.setBounds(346, 132, 78, 54);
		contentPane.add(btnlogin);
		
		JButton btnsignup = new JButton("\uAD00\uB9AC\uC790 \uB4F1\uB85D");
		btnsignup.setForeground(Color.WHITE);
		btnsignup.addActionListener(new ActionListener() { // ������ ���
			public void actionPerformed(ActionEvent e) {
				SignUp signup = new SignUp();
				signup.setVisible(true);
			}
		});
		btnsignup.setBackground(new Color(140, 190, 255));
		btnsignup.setFont(new Font("����������", Font.BOLD, 15));
		btnsignup.setBounds(327, 242, 111, 54);
		contentPane.add(btnsignup);
	}
}
