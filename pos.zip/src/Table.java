import java.awt.Color;
import java.util.*;

import javax.swing.JButton;

public class Table{
	public int tablenum;
	public int allordercnt;
	public Thread thread;
	public boolean isempty;
	public Vector<String> ordermenuname = new Vector<String>();
	public Vector<Integer> ordermenucnt = new Vector<Integer>();
	public Vector<Integer> ordermenustate = new Vector<Integer>();
	public Vector<String> ordermenutype = new Vector<String>();
	public Vector<Option> orderdrinkopt = new Vector<Option>();
	
	public Table() {};
	
	public void initTable(int tbnum){
		
		tablenum = tbnum;
		allordercnt = 0;
		isempty = true;
		
	}
	
	// ���̺��� �ֹ� �ޱ�
	public void SetTable(int tbnum, int allordercnt, Vector<String> menuname, Vector<Integer> menucnt, Vector<String> menutype) {
		isempty = false;
		tablenum = tbnum;
		for(int i=0;i<menuname.size();i++)
			ordermenuname.add(menuname.elementAt(i));
		for(int j=0;j<menucnt.size();j++)
			ordermenucnt.add(menucnt.elementAt(j));
		for(int s=0;s<allordercnt;s++)
			ordermenutype.add(menutype.elementAt(s));
		for(int k=0;k<menuname.size();k++)
			ordermenustate.add(100);
	}
	
	
	// ���̺��� �߰� �ֹ� �ޱ�
	public void ExtraSetTable(int tbnum, int allordercnt, Vector<String> menuname, Vector<Integer> menucnt, Vector<String> menutype) {
		isempty = false;
		tablenum = tbnum;
		for(int i=0;i<menuname.size();i++)
			ordermenuname.add(menuname.elementAt(i));
		for(int j=0;j<menucnt.size();j++)
			ordermenucnt.add(menucnt.elementAt(j));
		for(int s=0;s<allordercnt;s++)
			ordermenutype.add(menutype.elementAt(s));
		for(int k=0;k<menuname.size();k++)
			ordermenustate.add(100);
	}
	

	// ���̺� ġ���
	public void resettable() {
		ordermenuname.clear();
		ordermenucnt.clear();
		ordermenutype.clear();
		ordermenustate.clear();
		isempty = true;
	}
	
	
}
