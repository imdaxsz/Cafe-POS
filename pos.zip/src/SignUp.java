import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class SignUp extends JFrame {

	private JPanel contentPane;
	private JTextField TxtNewID;
	private JTextField TxtNewPW;
	private String[] position = {"Manager","Staff"};
	int memberopt = 0;
	
	Member member = new Member();
	private JTextField TxtNewName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setTitle("\uAD00\uB9AC\uC790 \uB4F1\uB85D");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 497, 371);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaptionBorder);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbnewID = new JLabel("ID");
		lbnewID.setHorizontalAlignment(SwingConstants.CENTER);
		lbnewID.setForeground(SystemColor.controlDkShadow);
		lbnewID.setFont(new Font("���������� Bold", Font.PLAIN, 25));
		lbnewID.setBounds(44, 163, 68, 35);
		contentPane.add(lbnewID);
		
		TxtNewID = new JTextField();
		TxtNewID.setFont(new Font("����������", Font.PLAIN, 15));
		TxtNewID.setColumns(10);
		TxtNewID.setBounds(115, 163, 231, 35);
		contentPane.add(TxtNewID);
		
		TxtNewPW = new JTextField();
		TxtNewPW.setFont(new Font("����������", Font.PLAIN, 15));
		TxtNewPW.setColumns(10);
		TxtNewPW.setBounds(115, 207, 231, 35);
		contentPane.add(TxtNewPW);
		
		TxtNewName = new JTextField();
		TxtNewName.setFont(new Font("����������", Font.PLAIN, 15));
		TxtNewName.setColumns(10);
		TxtNewName.setBounds(115, 118, 231, 35);
		contentPane.add(TxtNewName);
		
		JLabel lbNewName = new JLabel("\uC774\uB984");
		lbNewName.setHorizontalAlignment(SwingConstants.CENTER);
		lbNewName.setForeground(SystemColor.controlDkShadow);
		lbNewName.setFont(new Font("���������� Bold", Font.PLAIN, 25));
		lbNewName.setBounds(44, 118, 68, 35);
		contentPane.add(lbNewName);
		
		JLabel lbnewPW = new JLabel("PW");
		lbnewPW.setHorizontalAlignment(SwingConstants.CENTER);
		lbnewPW.setForeground(SystemColor.controlDkShadow);
		lbnewPW.setFont(new Font("���������� Bold", Font.PLAIN, 25));
		lbnewPW.setBounds(43, 208, 68, 35);
		contentPane.add(lbnewPW);
		
		JLabel lblSignUp = new JLabel("Sign Up");
		lblSignUp.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignUp.setForeground(new Color(25, 25, 112));
		lblSignUp.setFont(new Font("���������� Bold", Font.PLAIN, 30));
		lblSignUp.setBounds(125, 28, 223, 49);
		contentPane.add(lblSignUp);
		
		JRadioButton rbMaster = new JRadioButton("\uB9C8\uC2A4\uD130");
		rbMaster.setFont(new Font("����������", Font.PLAIN, 15));
		rbMaster.setHorizontalAlignment(SwingConstants.CENTER);
		rbMaster.setBackground(SystemColor.inactiveCaptionBorder);
		rbMaster.setBounds(112, 257, 80, 23);
		contentPane.add(rbMaster);
		rbMaster.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				memberopt = 1;
			}
		});
		
		JRadioButton rbManager = new JRadioButton("\uB9E4\uB2C8\uC800");
		rbManager.setHorizontalAlignment(SwingConstants.CENTER);
		rbManager.setFont(new Font("����������", Font.PLAIN, 15));
		rbManager.setBackground(SystemColor.inactiveCaptionBorder);
		rbManager.setBounds(190, 257, 80, 23);
		contentPane.add(rbManager);
		rbManager.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				memberopt = 2;
			}
		});
		
		JRadioButton rbStaff = new JRadioButton("\uC9C1\uC6D0");
		rbStaff.setFont(new Font("����������", Font.PLAIN, 15));
		rbStaff.setHorizontalAlignment(SwingConstants.CENTER);
		rbStaff.setBackground(SystemColor.inactiveCaptionBorder);
		rbStaff.setBounds(261, 257, 80, 23);
		contentPane.add(rbStaff);
		rbStaff.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				memberopt = 3;
			}
		});
		
		ButtonGroup group = new ButtonGroup();
		group.add(rbMaster); group.add(rbStaff);
		
		JButton btnadsignup = new JButton("\uB4F1\uB85D"); // ��� ��ư
		btnadsignup.setForeground(Color.WHITE);
		btnadsignup.setFont(new Font("����������", Font.BOLD, 15));
		btnadsignup.setBackground(new Color(140, 190, 255));
		btnadsignup.setBounds(363, 154, 78, 54);
		contentPane.add(btnadsignup);
		btnadsignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				member.adminstration(TxtNewName.getText(), TxtNewID.getText(), TxtNewPW.getText(), memberopt);
				System.out.println("complete");
				JOptionPane mgscomplete=new JOptionPane();
				mgscomplete.showMessageDialog(null, "����� �Ϸ�Ǿ����ϴ�.", "��� �Ϸ�", JOptionPane.INFORMATION_MESSAGE);
				dispose();
			}
		});
		
		JButton btnsignupcancel = new JButton("\uCDE8\uC18C"); // ��� ��ư
		btnsignupcancel.setForeground(Color.GRAY);
		btnsignupcancel.setFont(new Font("����������", Font.PLAIN, 13));
		btnsignupcancel.setBackground(new Color(242, 242, 242));
		btnsignupcancel.setBounds(387, 273, 76, 29);
		contentPane.add(btnsignupcancel);

		btnsignupcancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
	}
}
