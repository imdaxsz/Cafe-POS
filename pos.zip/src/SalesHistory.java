import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

import java.io.*;
import java.util.*;


public class SalesHistory extends JFrame {
	String FILE_NAME = "SalesHistory.txt";
	File file =  new File(FILE_NAME);
	
	String []a = {"�ǸŽð�","��ǰ��","����"};
    
    DefaultTableModel model = new DefaultTableModel(a, 0) {
    	public boolean isCellEditable(int rowIndex, int mColIndex) {
    		return false;
    	}
    };

	private JPanel contentPane;
	private JTextField txfsearch;
	private JTable salestable = new JTable(model);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesHistory frame = new SalesHistory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SalesHistory() { // ��ǰ �Ǹ� ����
		setTitle("\uD310\uB9E4\uB0B4\uC5ED");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 652, 505);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaptionBorder);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbsales = new JLabel("\uD310\uB9E4\uB0B4\uC5ED");
		lbsales.setForeground(new Color(0, 0, 139));
		lbsales.setFont(new Font("���������� Bold", Font.PLAIN, 25));
		lbsales.setHorizontalAlignment(SwingConstants.CENTER);
		lbsales.setBounds(208, 16, 188, 50);
		contentPane.add(lbsales);
		
		JScrollPane scrollPane = new JScrollPane(salestable);
		scrollPane.setBounds(76, 147, 480, 274);
		contentPane.add(scrollPane);
		
		salestable.getColumnModel().getColumn(0).setPreferredWidth(50); 
		salestable.getColumnModel().getColumn(0).setResizable(false);
		salestable.getColumnModel().getColumn(1).setPreferredWidth(100); 
		salestable.getColumnModel().getColumn(1).setResizable(false);
		salestable.getColumnModel().getColumn(2).setPreferredWidth(1); 
		salestable.getColumnModel().getColumn(2).setResizable(false);
		salestable.getTableHeader().setReorderingAllowed(false);
		scrollPane.setViewportView(salestable);
		salestable.setBackground(Color.WHITE);
		
		salestable.updateUI();
		
		txfsearch = new JTextField();
		txfsearch.setFont(new Font("����������", Font.PLAIN, 12));
		txfsearch.setText("");
		txfsearch.setColumns(10);
		txfsearch.setBounds(76, 85, 364, 35);
		contentPane.add(txfsearch);
		
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			String sLine = null;
			int index = 0;
			while((sLine = reader.readLine()) != null){
				String[] saleslist = sLine.split(" ");
				model.insertRow(index++,new Object[]{saleslist[0]+" "+saleslist[1],saleslist[2],saleslist[3]});
			}
		} catch(IOException e) {
			e.printStackTrace();
			System.out.println("����� ����");
		}
		
		JButton lbsearch = new JButton("\uC0C1\uD488 \uAC80\uC0C9");
		lbsearch.addActionListener(new ActionListener() { // �̸� ��� ��ǰ �˻�
			public void actionPerformed(ActionEvent e) {
				int resultcnt = 0;
				BufferedReader reader = null;
				try {
					reader = new BufferedReader(new FileReader(file));
					String sLine = null;
					int index = 0;
					while((sLine = reader.readLine()) != null){
						String[] saleslist = sLine.split(" ");
						if(saleslist[2].equals(txfsearch.getText())) {
							resultcnt++;
							if(resultcnt == 1)
								model.setRowCount(0);
							model.insertRow(index++,new Object[]{saleslist[0]+" "+saleslist[1],saleslist[2],saleslist[3]});
						}
					}
				} catch(IOException e1) {
					e1.printStackTrace();
					System.out.println("����� ����");
				}
				model.fireTableDataChanged();
				if(resultcnt==0) {
					JOptionPane mgsnoresult=new JOptionPane();
					mgsnoresult.showMessageDialog(null, "�ش� ��ǰ�� �Ǹ� ������ �����ϴ�.", "��ǰ �˻�", JOptionPane.INFORMATION_MESSAGE);
				}
			}

		});
		lbsearch.setForeground(Color.WHITE);
		lbsearch.setFont(new Font("����������", Font.BOLD, 15));
		lbsearch.setBackground(new Color(140, 190, 255));
		lbsearch.setBounds(452, 85, 102, 35);
		contentPane.add(lbsearch);
	}
}
