import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Extraorder extends JFrame {

	private JPanel extraorder;
	private JRadioButton rbextb1, rbextb2, rbextb3, rbextb4, rbextb5, rbextb6, rbextb7, rbextb8, rbextb9;
	public JRadioButton[] rbtable = {rbextb1, rbextb2, rbextb3, rbextb4, rbextb5, rbextb6, rbextb7, rbextb8, rbextb9};
	public Table tableinfo = new Table();
	public int tablenum = 0;
	public boolean orderok = false;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Extraorder frame = new Extraorder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Extraorder() {
		
	};
	public Extraorder(int tablecnt, Table[] tableorderlist, Vector<String> extmenuname, Vector<Integer> extmenucnt,
			Vector<String> extmenutype, int extordercnt,JTable table, DefaultTableModel model,
			Vector<Vector <String>> orderdetail) {
		orderok = false;
		setTitle("\uCD94\uAC00 \uC8FC\uBB38");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		extraorder = new JPanel();
		extraorder.setBackground(SystemColor.inactiveCaptionBorder);
		extraorder.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(extraorder);
		extraorder.setLayout(null);
		
		rbextb1 = new JRadioButton("\uD14C\uC774\uBE14 1");
		rbextb1.setBackground(Color.WHITE);
		rbextb1.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb1.setBounds(95, 69, 120, 30);
		extraorder.add(rbextb1);
		
		rbextb2 = new JRadioButton("\uD14C\uC774\uBE14 2");
		rbextb2.setBackground(Color.WHITE);
		rbextb2.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb2.setBounds(242, 69, 120, 30);
		extraorder.add(rbextb2);
		
		rbextb3 = new JRadioButton("\uD14C\uC774\uBE14 3");
		rbextb3.setBackground(Color.WHITE);
		rbextb3.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb3.setBounds(395, 69, 95, 30);
		extraorder.add(rbextb3);
		
		rbextb4 = new JRadioButton("\uD14C\uC774\uBE14 4");
		rbextb4.setBackground(Color.WHITE);
		rbextb4.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb4.setBounds(95, 149, 120, 30);
		extraorder.add(rbextb4);
		
		rbextb5 = new JRadioButton("\uD14C\uC774\uBE14 5");
		rbextb5.setBackground(Color.WHITE);
		rbextb5.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb5.setBounds(242, 149, 120, 30);
		extraorder.add(rbextb5);
		
		rbextb6 = new JRadioButton("\uD14C\uC774\uBE14 6");
		rbextb6.setBackground(Color.WHITE);
		rbextb6.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb6.setBounds(395, 149, 95, 30);
		extraorder.add(rbextb6);
		
		rbextb7 = new JRadioButton("\uD14C\uC774\uBE14 7");
		rbextb7.setBackground(Color.WHITE);
		rbextb7.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb7.setBounds(95, 229, 120, 30);
		rbextb7.setVisible(false);
		extraorder.add(rbextb7);
		
		rbextb8 = new JRadioButton("\uD14C\uC774\uBE14 8");
		rbextb8.setBackground(Color.WHITE);
		rbextb8.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb8.setBounds(242, 229, 120, 30);
		rbextb8.setVisible(false);
		extraorder.add(rbextb8);
		
		rbextb9 = new JRadioButton("\uD14C\uC774\uBE14 9");
		rbextb9.setBackground(Color.WHITE);
		rbextb9.setFont(new Font("����������", Font.PLAIN, 15));
		rbextb9.setBounds(395, 229, 90, 30);
		rbextb9.setVisible(false);
		extraorder.add(rbextb9);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rbextb1); group.add(rbextb2); group.add(rbextb3); group.add(rbextb4); group.add(rbextb5);
		group.add(rbextb6); group.add(rbextb7); group.add(rbextb8); group.add(rbextb9);
		
		JRadioButton[] rbtable = {rbextb1, rbextb2, rbextb3, rbextb4, rbextb5, rbextb6, rbextb7, rbextb8, rbextb9};
		
		for(int s=0;s<tablecnt;s++) { // ���� ���̺� ������ŭ ���� ��ư �ð�ȭ
			if(rbtable[s].isVisible()==false) {
				rbtable[s].setVisible(true);
			}			
		}
		
		for(int i=0;i<9;i++) { // ���̺� ��ȣ ����
			int k = i;
			rbtable[i].addItemListener(new ItemListener() {
			    public void itemStateChanged(ItemEvent e) {
			    	if(rbtable[k].isSelected())
			    		tablenum = k+1;
			    }
			});
		}
 
		JButton tbextraokbtn = new JButton("\uD655\uC778");
		tbextraokbtn.setFont(new Font("����������", Font.PLAIN, 15));
		tbextraokbtn.setBounds(300, 330, 90, 23);
		tbextraokbtn.setBackground(new Color(242, 242, 242));
		extraorder.add(tbextraokbtn);
		tbextraokbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tableinfo = tableorderlist[tablenum-1];
				tableinfo.ExtraSetTable(tablenum, extordercnt, extmenuname, extmenucnt, extmenutype);
				tableorderlist[tablenum-1]=tableinfo;
				for(int a=0;a<model.getRowCount();a++) {
					(orderdetail.elementAt(tablenum-1)).add(model.getValueAt(a, 0).toString());
					//System.out.print("Ȯ�� : " + orderdetail.elementAt(tablenum-1).elementAt(a));
				}
				dispose();
				orderok = true; // �ֹ� �Ϸ�
		 	}
		});
 
		JButton tbexcancelbtn = new JButton("\uCDE8\uC18C");
		tbexcancelbtn.setFont(new Font("����������", Font.PLAIN, 15));
		tbexcancelbtn.setBounds(173, 330, 90, 23);
		tbexcancelbtn.setBackground(new Color(242, 242, 242));
		extraorder.add(tbexcancelbtn);
		
		JPanel exorderpanel = new JPanel();
		exorderpanel.setBackground(Color.WHITE);
		exorderpanel.setBounds(58, 47, 457, 234);
		extraorder.add(exorderpanel);
		tbexcancelbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
	
}
