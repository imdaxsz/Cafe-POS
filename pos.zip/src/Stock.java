import java.util.Arrays;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

class Stock{
	String[] drinkstock = {"������(HOT)","�ö�ƽ��(ICE)", "����(HOT)", "����(ICE)"};
	String[] dessertstock = {"��ũ", "������"};
	String tissuestock = "Ƽ��";
	int[] drinkstockcnt = {10, 10, 10, 10};
	int[] dessertstockcnt = {10, 10};
	int tissuecnt = 20;
	Vector<String> stocklist = new Vector<String>(drinkstock.length+dessertstock.length+1);
	
	void StockList(){ // �Ҹ�ǰ ����Ʈ ����
		String[] allstock = new String[drinkstock.length+dessertstock.length+1];
		System.arraycopy(drinkstock,0,allstock,0,drinkstock.length);
		System.arraycopy(dessertstock,0,allstock,drinkstock.length,dessertstock.length);
		allstock[allstock.length-1]=tissuestock;
		Arrays.sort(allstock);
		
		for(int i=0;i<allstock.length;i++)
			stocklist.add(allstock[i]);
	}
}
