import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
public class Tableorder extends JFrame {

	private JPanel tablechoose;
	public Table tableinfo = new Table();
	public int tablenum = 0;
	public boolean orderok = false;
	
	private JRadioButton rbtb1, rbtb2, rbtb3, rbtb4, rbtb5, rbtb6, rbtb7, rbtb8, rbtb9;
	public JRadioButton[] rbtable = {rbtb1, rbtb2, rbtb3, rbtb4, rbtb5, rbtb6, rbtb7, rbtb8, rbtb9};
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tableorder frame = new Tableorder();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tableorder() {
		
	};
	public Tableorder(int tablecnt, Table[] tableorderlist, Vector<String> name, Vector<Integer> cnt, Vector<String> type, int allordercnt, JTable table, DefaultTableModel model, Vector<Vector <String>> orderdetail) {
		orderok = false;
		setTitle("\uD14C\uC774\uBE14 \uC120\uD0DD");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		tablechoose = new JPanel();
		tablechoose.setBackground(SystemColor.inactiveCaptionBorder);
		tablechoose.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(tablechoose);
		tablechoose.setLayout(null);
		
	
		rbtb1 = new JRadioButton("\uD14C\uC774\uBE14 1");
		rbtb1.setBackground(Color.WHITE);
		rbtb1.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb1.setBounds(95, 69, 120, 30);
		tablechoose.add(rbtb1);
		
		rbtb2 = new JRadioButton("\uD14C\uC774\uBE14 2");
		rbtb2.setBackground(Color.WHITE);
		rbtb2.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb2.setBounds(242, 69, 120, 30);
		tablechoose.add(rbtb2);
		
		rbtb3 = new JRadioButton("\uD14C\uC774\uBE14 3");
		rbtb3.setBackground(Color.WHITE);
		rbtb3.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb3.setBounds(395, 69, 90, 30);
		tablechoose.add(rbtb3);
		
		rbtb4 = new JRadioButton("\uD14C\uC774\uBE14 4");
		rbtb4.setBackground(Color.WHITE);
		rbtb4.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb4.setBounds(95, 149, 120, 30);
		tablechoose.add(rbtb4);
		
		rbtb5 = new JRadioButton("\uD14C\uC774\uBE14 5");
		rbtb5.setBackground(Color.WHITE);
		rbtb5.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb5.setBounds(242, 149, 120, 30);
		tablechoose.add(rbtb5);
		
		rbtb6 = new JRadioButton("\uD14C\uC774\uBE14 6");
		rbtb6.setBackground(Color.WHITE);
		rbtb6.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb6.setBounds(395, 149, 90, 30);
		tablechoose.add(rbtb6);
		
		rbtb7 = new JRadioButton("\uD14C\uC774\uBE14 7");
		rbtb7.setBackground(Color.WHITE);
		rbtb7.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb7.setBounds(95, 229, 120, 30);
		rbtb7.setVisible(false);
		tablechoose.add(rbtb7);
		
		rbtb8 = new JRadioButton("\uD14C\uC774\uBE14 8");
		rbtb8.setBackground(Color.WHITE);
		rbtb8.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb8.setBounds(242, 229, 120, 30);
		rbtb8.setVisible(false);
		tablechoose.add(rbtb8);
		
		rbtb9 = new JRadioButton("\uD14C\uC774\uBE14 9");
		rbtb9.setBackground(Color.WHITE);
		rbtb9.setFont(new Font("����������", Font.PLAIN, 15));
		rbtb9.setBounds(395, 229, 90, 30);
		rbtb9.setVisible(false);
		tablechoose.add(rbtb9);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rbtb1); group.add(rbtb2); group.add(rbtb3); group.add(rbtb4); group.add(rbtb5);
		group.add(rbtb6); group.add(rbtb7); group.add(rbtb8); group.add(rbtb9);
		
		JRadioButton[] rbtable = {rbtb1, rbtb2, rbtb3, rbtb4, rbtb5, rbtb6, rbtb7, rbtb8, rbtb9};
		
		for(int t=0;t<9;t++) { // ���̺��� �ֹ��� �޾����ִٸ� �ش� ���̺� ��ư ��Ȱ��ȭ
			if(tableorderlist[t].isempty==false)
				rbtable[t].setEnabled(false);
		}
		for(int s=0;s<tablecnt;s++) { // ���� ���̺� ������ŭ ���� ��ư �ð�ȭ
			if(rbtable[s].isVisible()==false) {
				rbtable[s].setVisible(true);
			}			
		}
		
		
		for(int i=0;i<9;i++) {
			int k = i;
			rbtable[i].addItemListener(new ItemListener() {
			    public void itemStateChanged(ItemEvent e) {
			    	if(rbtable[k].isSelected())
			    		tablenum = k+1;
			    }
			});
		}
		
		JButton tbcancelbtn = new JButton("\uCDE8\uC18C"); // ��� ��ư
		tbcancelbtn.setFont(new Font("����������", Font.PLAIN, 15));
		tbcancelbtn.setBounds(173, 330, 90, 23);
		tbcancelbtn.setBackground(new Color(242, 242, 242));
		tablechoose.add(tbcancelbtn);
		tbcancelbtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		
		JButton tbselectokbtn = new JButton("\uD655\uC778"); // Ȯ�� ��ư
		tbselectokbtn.setFont(new Font("����������", Font.PLAIN, 15));
		tbselectokbtn.setBounds(300, 330, 90, 23);
		tbselectokbtn.setBackground(new Color(242, 242, 242));
		tablechoose.add(tbselectokbtn);
		tbselectokbtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				tableinfo.SetTable(tablenum, allordercnt, name, cnt, type);
				tableorderlist[tablenum-1]=tableinfo;
				for(int a=0;a<model.getRowCount();a++) {
					(orderdetail.elementAt(tablenum-1)).add(model.getValueAt(a, 0).toString());
					System.out.print("temp�� : " + orderdetail.elementAt(tablenum-1).elementAt(a));
				}
				dispose();
				orderok = true;

			}
		});
 
		JPanel tborderpanel = new JPanel();
		tborderpanel.setBackground(Color.WHITE);
		tborderpanel.setBounds(58, 47, 457, 234);
		tablechoose.add(tborderpanel);

	}

}
